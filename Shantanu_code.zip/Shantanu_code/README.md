
## To implement the project, you can follow the tutorial video I made on YouTube https://www.youtube.com/watch?time_continue=1249&v=A2mqQdxnlqw 

<br>
<a href="https://www.youtube.com/watch?time_continue=1249&v=A2mqQdxnlqw" target="_blank"></a>

<br>

Use CocoaPods to integrate ARKit-CoreLocation ProjectDent https://github.com/ProjectDent/ARKit-CoreLocation 
into your Xcode project by following below steps:


<br>

> - Create a new Xcode project type of (Single View App) 

> - Open Terminal then type ( cd ) then drag your project root folder into the Terminal and press return 

> - Once you are inside your project in the Terminal, type (pod init) this will initialize a pod file in your project. 

> - Open your project folder using finder then open the pod file using Brackets or Atom get that done then follow ProjectDent instructions. 


Be aware that whenever you add a third party library to your project then that requires you to open it through the use of xcworkspace file. 


 Use https://www.canva.com/create/labels/  to create the label  (pins)
 
 Use https://www140.lunapic.com/editor/?action=transparentto make the background of the pin transparent.
 
 Use https://www.latlong.net/  to get the locations coordinates of the landmarks.


Make sure to add Privacy Camera Usage Description and Privacy
  Location when in Use Usage Descriptionin the plist file:

> Privacy Camera Usage Description 


> Privacy Location when in Use Usage Descriptionin
