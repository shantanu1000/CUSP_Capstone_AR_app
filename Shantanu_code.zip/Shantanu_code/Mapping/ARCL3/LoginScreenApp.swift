//
//  LoginScreenApp.swift
//  NYCSBUS 
//
//  Created by Shantanu Anikhindi on 6/27/23.
//  Copyright © 2023 Nasser Jeary. All rights reserved.
//

import SwiftUI

@main
struct LoginScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
