//
//  BusViewControllerRepresentable.swift
//  NYCSBUS 
//
//  Created by Shantanu Anikhindi on 6/28/23.
//  Copyright © 2023 Nasser Jeary. All rights reserved.
//
import SwiftUI
import UIKit

struct BusViewControllerRepresentable: UIViewControllerRepresentable {
    
    var busNumber: String

    typealias UIViewControllerType = BusARViewController // Replace BusViewController with BusARViewController

    func makeUIViewController(context: Context) -> BusARViewController {
        let controller = BusARViewController()
        controller.busNumber = busNumber
        return controller
    }

    func updateUIViewController(_ uiViewController: BusARViewController, context: Context) {
        uiViewController.busNumber = busNumber
    }
}
