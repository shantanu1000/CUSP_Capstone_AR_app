//
//  ViewControllerRepresentable.swift
//  NYCSBUS 
//
//  Created by Shantanu Anikhindi on 6/28/23.
//  Copyright © 2023 Nasser Jeary. All rights reserved.
//

import SwiftUI
import UIKit

struct ViewControllerRepresentable: UIViewControllerRepresentable {
    typealias UIViewControllerType = ViewController

    func makeUIViewController(context: Context) -> ViewController {
        // Instantiate your ViewController here
        return ViewController()
    }
    
    func updateUIViewController(_ uiViewController: ViewController, context: Context) {
        // Update your ViewController here
    }
}

