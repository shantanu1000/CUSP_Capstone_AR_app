//
//  EnterBusNumberView.swift
//  NYCSBUS 
//
//  Created by Shantanu Anikhindi on 6/27/23.
//  Copyright © 2023 Nasser Jeary. All rights reserved.
//
import SwiftUI

struct EnterBusNumberView: View {
    @State private var busNumber: String = ""
    @State private var showBusView: Bool = false

    var body: some View {
        NavigationView {
            ZStack {
                Color.yellow
                    .ignoresSafeArea()
                Circle()
                    .scale(1.5)
                    .foregroundColor(.white.opacity(0.15))
                Circle()
                    .scale(1.1)
                    .foregroundColor(.white.opacity(0.15))

                VStack {
                    Image("Sandwichito+(1)")
                        .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                        .aspectRatio(contentMode: .fit)
                        .padding(.all)
                        .frame(width: 400, height: 250.0)
                    Spacer()
                }

                VStack {
                    TextField("Enter Bus Number", text: $busNumber)
                        .keyboardType(.default) // changed keyboard type back to default since bus numbers are now strings
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.white.opacity(0.75))
                        .cornerRadius(10)

                    Button(action: {
                        self.showBusView = true
                    }) {
                        Text("Locate")
                            .foregroundColor(.white)
                            .frame(width: 300, height: 50)
                            .background(Color.black.opacity(0.9))
                            .cornerRadius(10)
                    }
                    
                    // The NavigationLink is now independent of the button, it is hidden and only activated when showBusView is true
                    NavigationLink(
                        destination: BusViewControllerRepresentable(busNumber: busNumber), // passing the bus number as string
                        isActive: $showBusView
                    ) {
                        EmptyView() // Hidden NavigationLink
                    }
                }
            }
        }
    }
}

struct EnterBusNumberView_Previews: PreviewProvider {
    static var previews: some View {
        EnterBusNumberView()
    }
}
