//
//  ContentView.swift
//  NYCSBUS 
//
//  Created by Shantanu Anikhindi on 6/27/23.
//  Copyright © 2023 Nasser Jeary. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var wrongUsername: Float = 0
    @State private var wrongPassword: Float  = 0
    @State private var isPasswordVisible = false
    @State private var isLoggedIn = false
    var body: some View {
        VStack {
            
            NavigationView {
                ZStack {
                    Color.yellow
                        .ignoresSafeArea()
                    Circle()
                        .scale(1.5)
                        .foregroundColor(.white.opacity(0.15))
                    Circle()
                        .scale(1.1)
                        .foregroundColor(.white.opacity(0.15))
                    VStack {
                        Image("Sandwichito+(1)")
                            .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                            .aspectRatio(contentMode: .fit)
                            .padding(.all)
                            .frame(width:400,height: 250.0)
                        Spacer()
                    }
                    VStack {
                        
                        TextField("Username", text: $username)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.75))
                            .cornerRadius(10)
                            .border(.red, width: CGFloat(wrongUsername))
                        
                        HStack {
                            if isPasswordVisible {
                                TextField("Password", text: $password)
                            } else {
                                SecureField("Password", text: $password)
                            }
                            Button(action: {
                                isPasswordVisible.toggle()
                            }) {
                                Image(systemName: isPasswordVisible ? "eye" : "eye.slash")
                                    .foregroundColor(.gray.opacity(0.5))
                            }
                        }
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.white.opacity(0.75))
                        .cornerRadius(10)
                        .border(.red, width: CGFloat(wrongPassword))
                        
                        Button("Sign in") {
                            authenticateUser(username: username, password: password)
                        }
                        .foregroundColor(.white)
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.9))
                        .cornerRadius(10)
                        .fullScreenCover(isPresented: $isLoggedIn, content: {
                            AfterLoginView(isLoggedIn: $isLoggedIn)
                        })
                    }.navigationBarHidden(true)
                }
            }
        }
    }
    
    
    func authenticateUser(username: String, password: String) {
        if username.lowercased() == "nycsbus123" && password.lowercased() == "team@r123" {
            wrongUsername = 0
            wrongPassword = 0
            isLoggedIn = true  // Add this line
        } else {
            wrongUsername = 2
            wrongPassword = 2
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


