import UIKit
import MapKit
import CoreLocation
import ARCL
import ARKit

struct Restroom {
    let title: String
    let latitude: Double
    let longitude: Double
}

struct GeoJSON: Codable {
    let features: [Feature]
}

struct Feature: Codable {
    let geometry: Geometry
}

struct Geometry: Codable {
    let coordinates: [Double]
}


class RestroomAnnotation: NSObject, MKAnnotation {
    let title: String?
    let coordinate: CLLocationCoordinate2D

    init(title: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.coordinate = coordinate
    }
}
class AROverlayView: UIView {
    let travelTimeLabel: UILabel
    let travelDistanceLabel: UILabel

    override init(frame: CGRect) {
        travelTimeLabel = UILabel()
        travelDistanceLabel = UILabel()

        super.init(frame: frame)

        // Set some dummy text for initial display
        travelTimeLabel.text = "Initial travel time"
        travelDistanceLabel.text = "Initial travel distance"

        // Set text color, font and shadow
        let customFont = UIFont.boldSystemFont(ofSize: 18) // Change the size to fit your needs
        let textColor = UIColor.yellow
        let shadow = NSShadow()
        shadow.shadowColor = UIColor.black
        shadow.shadowOffset = CGSize(width: 1, height: 1)

        travelTimeLabel.font = customFont
        travelTimeLabel.textColor = textColor
        travelTimeLabel.shadowColor = shadow.shadowColor as? UIColor
        travelTimeLabel.shadowOffset = shadow.shadowOffset

        travelDistanceLabel.font = customFont
        travelDistanceLabel.textColor = textColor
        travelDistanceLabel.shadowColor = shadow.shadowColor as? UIColor
        travelDistanceLabel.shadowOffset = shadow.shadowOffset

        // Add labels to the AR overlay view
        self.addSubview(travelTimeLabel)
        self.addSubview(travelDistanceLabel)

        // Layout configuration code...
        // Make sure the labels are properly laid out inside the view.
        travelTimeLabel.translatesAutoresizingMaskIntoConstraints = false
        travelDistanceLabel.translatesAutoresizingMaskIntoConstraints = false
        
        // Set up constraints for labels to display them correctly
        NSLayoutConstraint.activate([
            travelTimeLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            travelTimeLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            travelTimeLabel.topAnchor.constraint(equalTo: self.topAnchor),
            travelTimeLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
            
            travelDistanceLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            travelDistanceLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            travelDistanceLabel.topAnchor.constraint(equalTo: travelTimeLabel.bottomAnchor),
            travelDistanceLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
            travelDistanceLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor), // Set the bottom constraint
        ])

    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    var sceneLocationView = SceneLocationView()
    var mapView = MKMapView()
    let locationManager = CLLocationManager()
    var currentCoordinate: CLLocationCoordinate2D?
    var restrooms: [Restroom] = []
    var currentRoute: MKRoute?
    var anchors: [ARGeoAnchor] = []
    var arOverlayView: AROverlayView?
    var currentAnnotationNode: LocationAnnotationNode?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setting up the delegates
        mapView.delegate = self
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.worldAlignment = .gravityAndHeading
        
        // Setting up the AR view
        sceneLocationView.run()
        sceneLocationView.session.run(configuration)
        sceneLocationView.pointOfView?.camera?.zFar = 1000  // Set the far clipping plane to 1000 meters
        
        // Setting up the Map view
        configureLocationServices()
        loadRestroomLocations()
        
        // Adding both the Map and AR view to a stack view and add it to the view hierarchy
        let stackView = UIStackView(arrangedSubviews: [sceneLocationView, mapView])
        stackView.axis = .vertical
        stackView.distribution = .fillEqually
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        // Constraints for stack view to fill the entire view
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stackView.topAnchor.constraint(equalTo: view.topAnchor),
            stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
        if let arOverlayView = arOverlayView {
            sceneLocationView.addSubview(arOverlayView)
        }
    }
    
    
    func loadImageAnnotation(named: String) -> SCNNode? {
        let annotationImage = UIImage(named: named)
        let annotationPlane = SCNPlane(width: 1.0, height: 1.0)
        annotationPlane.firstMaterial?.diffuse.contents = annotationImage
        let annotationNode = SCNNode(geometry: annotationPlane)
        annotationNode.eulerAngles.x = -.pi / 2  // Correct the orientation of the image
        return annotationNode
    }
    
    
    
    func configureLocationServices() {
        locationManager.delegate = self
        let authorizationStatus = locationManager.authorizationStatus  // Access the property directly
        if authorizationStatus == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        } else if authorizationStatus == .authorizedAlways || authorizationStatus == .authorizedWhenInUse {
            beginLocationUpdates(locationManager: locationManager)
        }
    }
    
    func beginLocationUpdates(locationManager: CLLocationManager) {
        mapView.showsUserLocation = true
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
    }
    
    func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
        let zoomRegion = MKCoordinateRegion.init(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(zoomRegion, animated: true)
    }
    
    func addRestroomLocations() {
        restrooms.forEach { restroom in
            let annotation = RestroomAnnotation(title: restroom.title, coordinate: CLLocationCoordinate2D(latitude: restroom.latitude, longitude: restroom.longitude))
            mapView.addAnnotation(annotation)
        }
    }
    
    
    func loadRestroomLocations() {
        guard let url = Bundle.main.url(forResource: "export", withExtension: "geojson") else { return }
        do {
            let data = try Data(contentsOf: url)
            let geoJSON = try JSONDecoder().decode(GeoJSON.self, from: data)
            geoJSON.features.forEach { feature in
                let title = "Restroom"
                let latitude = feature.geometry.coordinates[1]
                let longitude = feature.geometry.coordinates[0]
                let restroom = Restroom(title: title, latitude: latitude, longitude: longitude)
                restrooms.append(restroom)
            }
            addRestroomLocations()
        } catch {
            print(error)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let latestLocation = locations.first else { return }
        if currentCoordinate == nil {
            zoomToLatestLocation(with: latestLocation.coordinate)
        }
        
        currentCoordinate = latestLocation.coordinate
        
        // If there's a current destination, regenerate the route
        if let destination = mapView.selectedAnnotations.first?.coordinate {
            generateRoute(to: destination)
        }
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
            beginLocationUpdates(locationManager: manager)
        }
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        guard let coordinate = view.annotation?.coordinate else { return }
        
        // Clear the previous path if any
        if let currentRoute = self.currentRoute {
            self.mapView.removeOverlay(currentRoute.polyline)
            self.currentRoute = nil
        }
        
        if let arOverlayView = arOverlayView {
            arOverlayView.removeFromSuperview()
            self.arOverlayView = nil
        }
        
        // Deselect all annotations
        let allAnnotations = mapView.annotations
        allAnnotations.forEach { mapView.deselectAnnotation($0, animated: false) }
        
        // Clear the previous anchor if any
        sceneLocationView.removeAllNodes()
        
        // Place the new AR node
        let location = CLLocation(coordinate: coordinate, altitude: 10)
        let image = UIImage(named: "restroom")!
        let annotationNode = LocationAnnotationNode(location: location, image: image)
        sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
        
        generateRoute(to: coordinate)
    }
    
    
    func generateRoute(to destination: CLLocationCoordinate2D) {
        guard let sourceCoordinate = currentCoordinate else { return }
        
        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
        let destinationPlacemark = MKPlacemark(coordinate: destination)
        
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destinationItem = MKMapItem(placemark: destinationPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceItem
        directionRequest.destination = destinationItem
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] (response, error) in
            guard let response = response else { return } // handle error
            self?.currentRoute = response.routes[0]
            self?.mapView.addOverlay((self?.currentRoute!.polyline)!)
            
            // Retrieve the travel time and distance
            let travelTime = response.routes[0].expectedTravelTime / 60
            let travelDistance = response.routes[0].distance / 1609.34
            
            // Start AR session with the travel information
            self?.startARSession(to: destination, travelTime: travelTime, travelDistance: travelDistance)
        }
    }
    
    func startARSession(to destination: CLLocationCoordinate2D, travelTime: TimeInterval, travelDistance: CLLocationDistance) {
        // Create and set up AR overlay view
        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
        if let arOverlayView = arOverlayView {
            // Display the raw `travelTime` and `travelDistance` values.
            arOverlayView.travelTimeLabel.text = String(format: " Time: %.2f minutes", travelTime)
            arOverlayView.travelDistanceLabel.text = String(format: "Travel distance: %.2f miles", travelDistance)
            sceneLocationView.addSubview(arOverlayView)
        }
    }
    
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = .blue
            renderer.lineWidth = 3
            return renderer
        }
        return MKOverlayRenderer()
    }
    
    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
        for anchor in anchors {
            if let geoAnchor = anchor as? ARGeoAnchor {
                guard let currentCoordinate = currentCoordinate else { return }
                
                let distance = calculateDistance(from: geoAnchor.coordinate, to: currentCoordinate)
                
                // print or debug values here
                print("Distance: \(distance), GeoAnchor Coordinate: \(geoAnchor.coordinate)")
                
                if let annotationNode = loadImageAnnotation(named: "restroom") {  // Replace "Image_Name" with the name of your image file
                    let anchorNode = SCNNode()
                    anchorNode.addChildNode(annotationNode)
                    anchorNode.simdTransform = geoAnchor.transform // Set the transform of the anchor node to the anchor's transform
                    
                    // Add the node to the scene
                    sceneLocationView.scene.rootNode.addChildNode(anchorNode)
                }
            }
        }
    }
    
    
    
    
    
    
    func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return from.distance(from: to) // in meters
    }
    
    
    
    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        for anchor in anchors {
            if let geoAnchor = anchor as? ARGeoAnchor {
                print("GeoAnchor updated: \(geoAnchor)")
            }
        }
    }
    
    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
        for anchor in anchors {
            if let geoAnchor = anchor as? ARGeoAnchor {
                print("GeoAnchor removed: \(geoAnchor)")
                
                sceneLocationView.scene.rootNode.enumerateChildNodes { node, _ in
                    node.removeFromParentNode()
                }
            }
        }
    }
}

//import UIKit
//import MapKit
//import CoreLocation
//import ARCL
//import ARKit
//
//struct Restroom {
//    let title: String
//    let latitude: Double
//    let longitude: Double
//}
//
//struct GeoJSON: Codable {
//    let features: [Feature]
//}
//
//struct Feature: Codable {
//    let geometry: Geometry
//}
//
//struct Geometry: Codable {
//    let coordinates: [Double]
//}
//
//
//class RestroomAnnotation: NSObject, MKAnnotation {
//    let title: String?
//    let coordinate: CLLocationCoordinate2D
//
//    init(title: String, coordinate: CLLocationCoordinate2D) {
//        self.title = title
//        self.coordinate = coordinate
//    }
//}
//class AROverlayView: UIView {
//    let travelTimeLabel: UILabel
//    let travelDistanceLabel: UILabel
//
//    override init(frame: CGRect) {
//        travelTimeLabel = UILabel()
//        travelDistanceLabel = UILabel()
//
//        super.init(frame: frame)
//
//        // Set some dummy text for initial display
//        travelTimeLabel.text = "Initial travel time"
//        travelDistanceLabel.text = "Initial travel distance"
//
//        // Set text color, font and shadow
//        let customFont = UIFont.boldSystemFont(ofSize: 18) // Change the size to fit your needs
//        let textColor = UIColor.yellow
//        let shadow = NSShadow()
//        shadow.shadowColor = UIColor.black
//        shadow.shadowOffset = CGSize(width: 1, height: 1)
//
//        travelTimeLabel.font = customFont
//        travelTimeLabel.textColor = textColor
//        travelTimeLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelTimeLabel.shadowOffset = shadow.shadowOffset
//
//        travelDistanceLabel.font = customFont
//        travelDistanceLabel.textColor = textColor
//        travelDistanceLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelDistanceLabel.shadowOffset = shadow.shadowOffset
//
//        // Add labels to the AR overlay view
//        self.addSubview(travelTimeLabel)
//        self.addSubview(travelDistanceLabel)
//
//        // Layout configuration code...
//        // Make sure the labels are properly laid out inside the view.
//        travelTimeLabel.translatesAutoresizingMaskIntoConstraints = false
//        travelDistanceLabel.translatesAutoresizingMaskIntoConstraints = false
//        
//        // Set up constraints for labels to display them correctly
//        NSLayoutConstraint.activate([
//            travelTimeLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelTimeLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelTimeLabel.topAnchor.constraint(equalTo: self.topAnchor),
//            travelTimeLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            
//            travelDistanceLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelDistanceLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelDistanceLabel.topAnchor.constraint(equalTo: travelTimeLabel.bottomAnchor),
//            travelDistanceLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            travelDistanceLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor), // Set the bottom constraint
//        ])
//
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//
//class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
//    
//    var sceneLocationView = SceneLocationView()
//    var mapView = MKMapView()
//    let locationManager = CLLocationManager()
//    var currentCoordinate: CLLocationCoordinate2D?
//    var restrooms: [Restroom] = []
//    var currentRoute: MKRoute?
//    var anchors: [ARGeoAnchor] = []
//    var arOverlayView: AROverlayView?
//    var currentAnnotationNode: LocationAnnotationNode?
//    var updateRouteTimer: Timer?
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Setting up the delegates
//        mapView.delegate = self
//        
//        let configuration = ARWorldTrackingConfiguration()
//        configuration.worldAlignment = .gravityAndHeading
//        
//        // Setting up the AR view
//        sceneLocationView.run()
//        sceneLocationView.session.run(configuration)
//        sceneLocationView.pointOfView?.camera?.zFar = 1000  // Set the far clipping plane to 1000 meters
//        
//        // Setting up the Map view
//        configureLocationServices()
//        loadRestroomLocations()
//        
//        // Adding both the Map and AR view to a stack view and add it to the view hierarchy
//        let stackView = UIStackView(arrangedSubviews: [sceneLocationView, mapView])
//        stackView.axis = .vertical
//        stackView.distribution = .fillEqually
//        stackView.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(stackView)
//        
//        // Constraints for stack view to fill the entire view
//        NSLayoutConstraint.activate([
//            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            stackView.topAnchor.constraint(equalTo: view.topAnchor),
//            stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//        ])
//        
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    
//    
//    func loadImageAnnotation(named: String) -> SCNNode? {
//        let annotationImage = UIImage(named: named)
//        let annotationPlane = SCNPlane(width: 1.0, height: 1.0)
//        annotationPlane.firstMaterial?.diffuse.contents = annotationImage
//        let annotationNode = SCNNode(geometry: annotationPlane)
//        annotationNode.eulerAngles.x = -.pi / 2  // Correct the orientation of the image
//        return annotationNode
//    }
//    
//    
//    
//    func configureLocationServices() {
//        locationManager.delegate = self
//        let authorizationStatus = locationManager.authorizationStatus  // Access the property directly
//        if authorizationStatus == .notDetermined {
//            locationManager.requestWhenInUseAuthorization()
//        } else if authorizationStatus == .authorizedAlways || authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: locationManager)
//        }
//    }
//    
//    func beginLocationUpdates(locationManager: CLLocationManager) {
//        mapView.showsUserLocation = true
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.startUpdatingLocation()
//    }
//    
//    func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
//        let zoomRegion = MKCoordinateRegion.init(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
//        mapView.setRegion(zoomRegion, animated: true)
//    }
//    
//    func addRestroomLocations() {
//        restrooms.forEach { restroom in
//            let annotation = RestroomAnnotation(title: restroom.title, coordinate: CLLocationCoordinate2D(latitude: restroom.latitude, longitude: restroom.longitude))
//            mapView.addAnnotation(annotation)
//        }
//    }
//    
//    
//    func loadRestroomLocations() {
//        guard let url = Bundle.main.url(forResource: "export", withExtension: "geojson") else { return }
//        do {
//            let data = try Data(contentsOf: url)
//            let geoJSON = try JSONDecoder().decode(GeoJSON.self, from: data)
//            geoJSON.features.forEach { feature in
//                let title = "Restroom"
//                let latitude = feature.geometry.coordinates[1]
//                let longitude = feature.geometry.coordinates[0]
//                let restroom = Restroom(title: title, latitude: latitude, longitude: longitude)
//                restrooms.append(restroom)
//            }
//            addRestroomLocations()
//        } catch {
//            print(error)
//        }
//    }
//    
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        guard let latestLocation = locations.first else { return }
//        if currentCoordinate == nil {
//            zoomToLatestLocation(with: latestLocation.coordinate)
//        }
//        
//        currentCoordinate = latestLocation.coordinate
//        
//        // If there's a current destination, regenerate the route
//        if let destination = mapView.selectedAnnotations.first?.coordinate {
//            generateRoute(to: destination)
//        }
//    }
//    
//    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
//        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: manager)
//        }
//    }
//    
//    
//    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//        guard let coordinate = view.annotation?.coordinate else { return }
//        updateRouteTimer?.invalidate()
//          updateRouteTimer = nil
//        
//        // Clear the previous path if any
//        if let currentRoute = self.currentRoute {
//            self.mapView.removeOverlay(currentRoute.polyline)
//            self.currentRoute = nil
//        }
//        
//        if let arOverlayView = arOverlayView {
//            arOverlayView.removeFromSuperview()
//            self.arOverlayView = nil
//        }
//        
//        // Deselect all annotations
//        let allAnnotations = mapView.annotations
//        allAnnotations.forEach { mapView.deselectAnnotation($0, animated: false) }
//        
//        // Clear the previous anchor if any
//        sceneLocationView.removeAllNodes()
//        
//        // Place the new AR node
//        let location = CLLocation(coordinate: coordinate, altitude: 10)
//        let image = UIImage(named: "restroom")!
//        let annotationNode = LocationAnnotationNode(location: location, image: image)
//        sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
//        
//        generateRoute(to: coordinate)
//        
//        updateRouteTimer?.invalidate()
//                updateRouteTimer = nil
//                
//                // Restart the route update timer
//                updateRouteTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { [weak self] _ in
//                    self?.generateRoute(to: coordinate)
//                }
//    }
//    
//    
//    func generateRoute(to destination: CLLocationCoordinate2D) {
//        guard let sourceCoordinate = currentCoordinate else { return }
//        
//        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
//        let destinationPlacemark = MKPlacemark(coordinate: destination)
//        
//        let sourceItem = MKMapItem(placemark: sourcePlacemark)
//        let destinationItem = MKMapItem(placemark: destinationPlacemark)
//        
//        let directionRequest = MKDirections.Request()
//        directionRequest.source = sourceItem
//        directionRequest.destination = destinationItem
//        directionRequest.transportType = .automobile
//        
//        let directions = MKDirections(request: directionRequest)
//        directions.calculate { [weak self] (response, error) in
//            guard let response = response else { return } // handle error
//            self?.currentRoute = response.routes[0]
//            self?.mapView.addOverlay((self?.currentRoute!.polyline)!)
//            
//            // Retrieve the travel time and distance
//            let travelTime = response.routes[0].expectedTravelTime / 60
//            let travelDistance = response.routes[0].distance / 1609.34
//            
//            // Start AR session with the travel information
//            self?.startARSession(to: destination, travelTime: travelTime, travelDistance: travelDistance)
//        }
//    }
//    
//    func startARSession(to destination: CLLocationCoordinate2D, travelTime: TimeInterval, travelDistance: CLLocationDistance) {
//        // Create and set up AR overlay view
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            // Display the raw `travelTime` and `travelDistance` values.
//            arOverlayView.travelTimeLabel.text = String(format: " Time: %.2f minutes", travelTime)
//            arOverlayView.travelDistanceLabel.text = String(format: "Travel distance: %.2f miles", travelDistance)
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    
//    
//    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
//        if let polyline = overlay as? MKPolyline {
//            let renderer = MKPolylineRenderer(polyline: polyline)
//            renderer.strokeColor = .blue
//            renderer.lineWidth = 3
//            return renderer
//        }
//        return MKOverlayRenderer()
//    }
//    
//    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                guard let currentCoordinate = currentCoordinate else { return }
//                
//                let distance = calculateDistance(from: geoAnchor.coordinate, to: currentCoordinate)
//                
//                // print or debug values here
//                print("Distance: \(distance), GeoAnchor Coordinate: \(geoAnchor.coordinate)")
//                
//                if let annotationNode = loadImageAnnotation(named: "restroom") {  // Replace "Image_Name" with the name of your image file
//                    let anchorNode = SCNNode()
//                    anchorNode.addChildNode(annotationNode)
//                    anchorNode.simdTransform = geoAnchor.transform // Set the transform of the anchor node to the anchor's transform
//                    
//                    // Add the node to the scene
//                    sceneLocationView.scene.rootNode.addChildNode(anchorNode)
//                }
//            }
//        }
//    }
//    
//    func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
//        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
//        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
//        return from.distance(from: to) // in meters
//    }
//    
//    
//    
//    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor updated: \(geoAnchor)")
//            }
//        }
//    }
//    
//    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor removed: \(geoAnchor)")
//                
//                sceneLocationView.scene.rootNode.enumerateChildNodes { node, _ in
//                    node.removeFromParentNode()
//                }
//            }
//        }
//    }
//}


//import UIKit
//import MapKit
//import CoreLocation
//import ARCL
//import ARKit
//
//struct Restroom {
//    let title: String
//    let latitude: Double
//    let longitude: Double
//}
//
//struct GeoJSON: Codable {
//    let features: [Feature]
//}
//
//struct Feature: Codable {
//    let geometry: Geometry
//}
//
//struct Geometry: Codable {
//    let coordinates: [Double]
//}
//
//
//class RestroomAnnotation: NSObject, MKAnnotation {
//    let title: String?
//    let coordinate: CLLocationCoordinate2D
//
//    init(title: String, coordinate: CLLocationCoordinate2D) {
//        self.title = title
//        self.coordinate = coordinate
//    }
//}
//class AROverlayView: UIView {
//    let travelTimeLabel: UILabel
//    let travelDistanceLabel: UILabel
//
//    override init(frame: CGRect) {
//        travelTimeLabel = UILabel()
//        travelDistanceLabel = UILabel()
//
//        super.init(frame: frame)
//
//        // Set some dummy text for initial display
//        travelTimeLabel.text = "Initial travel time"
//        travelDistanceLabel.text = "Initial travel distance"
//
//        // Set text color, font and shadow
//        let customFont = UIFont.boldSystemFont(ofSize: 18) // Change the size to fit your needs
//        let textColor = UIColor.yellow
//        let shadow = NSShadow()
//        shadow.shadowColor = UIColor.black
//        shadow.shadowOffset = CGSize(width: 1, height: 1)
//
//        travelTimeLabel.font = customFont
//        travelTimeLabel.textColor = textColor
//        travelTimeLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelTimeLabel.shadowOffset = shadow.shadowOffset
//
//        travelDistanceLabel.font = customFont
//        travelDistanceLabel.textColor = textColor
//        travelDistanceLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelDistanceLabel.shadowOffset = shadow.shadowOffset
//
//        // Add labels to the AR overlay view
//        self.addSubview(travelTimeLabel)
//        self.addSubview(travelDistanceLabel)
//
//        // Layout configuration code...
//        // Make sure the labels are properly laid out inside the view.
//        travelTimeLabel.translatesAutoresizingMaskIntoConstraints = false
//        travelDistanceLabel.translatesAutoresizingMaskIntoConstraints = false
//        
//        // Set up constraints for labels to display them correctly
//        NSLayoutConstraint.activate([
//            travelTimeLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelTimeLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelTimeLabel.topAnchor.constraint(equalTo: self.topAnchor),
//            travelTimeLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            
//            travelDistanceLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelDistanceLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelDistanceLabel.topAnchor.constraint(equalTo: travelTimeLabel.bottomAnchor),
//            travelDistanceLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            travelDistanceLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor), // Set the bottom constraint
//        ])
//
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//
//class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
//    
//    var sceneLocationView = SceneLocationView()
//    var mapView = MKMapView()
//    let locationManager = CLLocationManager()
//    var currentCoordinate: CLLocationCoordinate2D?
//    var restrooms: [Restroom] = []
//    var currentRoute: MKRoute?
//    var anchors: [ARGeoAnchor] = []
//    var arOverlayView: AROverlayView?
//    var currentAnnotationNode: LocationAnnotationNode?
//    var anchorNodeDictionary = [ARGeoAnchor: SCNNode]()
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Setting up the delegates
//        mapView.delegate = self
//        
//        let configuration = ARWorldTrackingConfiguration()
//        configuration.worldAlignment = .gravityAndHeading
//        
//        // Setting up the AR view
//        sceneLocationView.run()
//        sceneLocationView.session.run(configuration)
//        sceneLocationView.pointOfView?.camera?.zFar = 1000  // Set the far clipping plane to 1000 meters
//        
//        // Setting up the Map view
//        configureLocationServices()
//        loadRestroomLocations()
//        
//        // Adding both the Map and AR view to a stack view and add it to the view hierarchy
//        let stackView = UIStackView(arrangedSubviews: [sceneLocationView, mapView])
//        stackView.axis = .vertical
//        stackView.distribution = .fillEqually
//        stackView.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(stackView)
//        
//        // Constraints for stack view to fill the entire view
//        NSLayoutConstraint.activate([
//            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            stackView.topAnchor.constraint(equalTo: view.topAnchor),
//            stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//        ])
//        
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    
//    
//    func loadImageAnnotation(named: String) -> SCNNode? {
//        let annotationImage = UIImage(named: named)
//        let annotationPlane = SCNPlane(width: 1.0, height: 1.0)
//        annotationPlane.firstMaterial?.diffuse.contents = annotationImage
//        let annotationNode = SCNNode(geometry: annotationPlane)
//        annotationNode.eulerAngles.x = -.pi / 2  // Correct the orientation of the image
//        return annotationNode
//    }
//    
//    
//    
//    func configureLocationServices() {
//        locationManager.delegate = self
//        let authorizationStatus = locationManager.authorizationStatus  // Access the property directly
//        if authorizationStatus == .notDetermined {
//            locationManager.requestWhenInUseAuthorization()
//        } else if authorizationStatus == .authorizedAlways || authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: locationManager)
//        }
//    }
//    
//    func beginLocationUpdates(locationManager: CLLocationManager) {
//        mapView.showsUserLocation = true
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.startUpdatingLocation()
//    }
//    
//    func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
//        let zoomRegion = MKCoordinateRegion.init(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
//        mapView.setRegion(zoomRegion, animated: true)
//    }
//    
//    func addRestroomLocations() {
//        restrooms.forEach { restroom in
//            let annotation = RestroomAnnotation(title: restroom.title, coordinate: CLLocationCoordinate2D(latitude: restroom.latitude, longitude: restroom.longitude))
//            mapView.addAnnotation(annotation)
//        }
//    }
//    
//    
//    func loadRestroomLocations() {
//        guard let url = Bundle.main.url(forResource: "export", withExtension: "geojson") else { return }
//        do {
//            let data = try Data(contentsOf: url)
//            let geoJSON = try JSONDecoder().decode(GeoJSON.self, from: data)
//            geoJSON.features.forEach { feature in
//                let title = "Restroom"
//                let latitude = feature.geometry.coordinates[1]
//                let longitude = feature.geometry.coordinates[0]
//                let restroom = Restroom(title: title, latitude: latitude, longitude: longitude)
//                restrooms.append(restroom)
//            }
//            addRestroomLocations()
//        } catch {
//            print(error)
//        }
//    }
//    
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        guard let latestLocation = locations.first else { return }
//        if currentCoordinate == nil {
//            zoomToLatestLocation(with: latestLocation.coordinate)
//        }
//        
//        currentCoordinate = latestLocation.coordinate
//        
//        // If there's a current destination, regenerate the route
//        if let destination = mapView.selectedAnnotations.first?.coordinate {
//            generateRoute(to: destination)
//        }
//    }
//    
//    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
//        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: manager)
//        }
//    }
//    
//    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//        guard let coordinate = view.annotation?.coordinate else { return }
//        
//        // Clear the previous path if any
//        if let currentRoute = self.currentRoute {
//            self.mapView.removeOverlay(currentRoute.polyline)
//            self.currentRoute = nil
//        }
//        
//        if let arOverlayView = arOverlayView {
//            arOverlayView.removeFromSuperview()
//            self.arOverlayView = nil
//        }
//        
//        // Deselect all annotations
//        let allAnnotations = mapView.annotations
//        allAnnotations.forEach { mapView.deselectAnnotation($0, animated: false) }
//        
//        // Clear the previous anchor if any
//        sceneLocationView.removeAllNodes()
//        
//        // Place the new AR node
//        let location = CLLocation(coordinate: coordinate, altitude: 10)
//        let image = UIImage(named: "restroom")!
//        let annotationNode = LocationAnnotationNode(location: location, image: image)
//        sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
//        
//        generateRoute(to: coordinate)
//    }
//    
//    
//    func generateRoute(to destination: CLLocationCoordinate2D) {
//        guard let sourceCoordinate = currentCoordinate else { return }
//
//        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
//        let destinationPlacemark = MKPlacemark(coordinate: destination)
//
//        let sourceItem = MKMapItem(placemark: sourcePlacemark)
//        let destinationItem = MKMapItem(placemark: destinationPlacemark)
//
//        let directionRequest = MKDirections.Request()
//        directionRequest.source = sourceItem
//        directionRequest.destination = destinationItem
//        directionRequest.transportType = .automobile
//
//        let directions = MKDirections(request: directionRequest)
//        directions.calculate { [weak self] (response, error) in
//            guard let response = response else { return } // handle error
//            self?.currentRoute = response.routes[0]
//            self?.mapView.addOverlay((self?.currentRoute!.polyline)!)
//
//            // Retrieve the travel time and distance
//            let travelTime = response.routes[0].expectedTravelTime / 60
//            let travelDistance = response.routes[0].distance / 1609.34
//
//            // Create ARGeoAnchors for each turn point in the route
//            self?.anchors = response.routes[0].steps.map { step in
//                let coordinate = step.polyline.coordinate
//                print("Step coordinate: \(coordinate)")  // add this line
//                let location = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
//                let name = "Anchor_\(coordinate.latitude)_\(coordinate.longitude)"
//                return ARGeoAnchor(name: name, coordinate: location.coordinate)
//            }
//
//            self?.animateObjectOnRoute()
//            // Start AR session with the travel information
//            self?.startARSession(to: destination, travelTime: travelTime, travelDistance: travelDistance)
//        }
//    }
//
//    
//    func animateObjectOnRoute() {
//        guard !anchors.isEmpty else { return }
//
//        // Create a sphere to move along the route
//        let sphere = SCNSphere(radius: 0.1)
//               let material = SCNMaterial()
//               material.diffuse.contents = UIColor.red
//               sphere.materials = [material]
//               let sphereNode = SCNNode(geometry: sphere)
//
//               // Add the sphere node to the AR scene
//               sceneLocationView.scene.rootNode.addChildNode(sphereNode)
//
//               // Set initial position
//               let startAnchor = anchors[0]
//               if let startNode = anchorNodeDictionary[startAnchor] {  // Use the node corresponding to the startAnchor
//                   sphereNode.position = startNode.position
//               }
//
//               // Start the animation
//               self.moveSphere(sphereNode, currentIndex: 0)
//           }
//
//    
//    func moveSphere(_ sphereNode: SCNNode, currentIndex: Int) {
//        guard currentIndex + 1 < anchors.count else { return }  // No more anchors to move towards
//
//        _ = anchors[currentIndex]
//        let nextAnchor = anchors[currentIndex + 1]
//
//        // Convert the next anchor's geographic coordinates to 3D space coordinates
//        let nextPosition = coordinateToVector3(nextAnchor.coordinate)
//
//        // Set the sphere to look at the next anchor's position
//        sphereNode.look(at: nextPosition)
//
//        // Animate the sphere to the next anchor's position
//        let action = SCNAction.move(to: nextPosition, duration: 3.0)
//        sphereNode.runAction(action) {
//            // After the action completes, move to the next anchor
//            self.moveSphere(sphereNode, currentIndex: currentIndex + 1)
//        }
//    }
//
//    func coordinateToVector3(_ coordinate: CLLocationCoordinate2D) -> SCNVector3 {
//        // Here we convert latitude and longitude to x, y, and z values. This conversion is a simplistic
//        // approximation and might not work correctly for large distances or close to the poles.
//        // For more accurate conversion, consider using a geodetic to ECEF (Earth-Centered, Earth-Fixed) conversion.
//        let earthRadius: Double = 6371.0
//        let latRad = coordinate.latitude * (.pi / 180)
//        let lonRad = coordinate.longitude * (.pi / 180)
//
//        let x = earthRadius * cos(latRad) * cos(lonRad)
//        let y = earthRadius * sin(latRad)
//        let z = -earthRadius * cos(latRad) * sin(lonRad)
//
//        return SCNVector3(x, y, z)
//    }
//
//    func startARSession(to destination: CLLocationCoordinate2D, travelTime: TimeInterval, travelDistance: CLLocationDistance) {
//        // Create and set up AR overlay view
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            // Display the raw `travelTime` and `travelDistance` values.
//            arOverlayView.travelTimeLabel.text = String(format: " Time: %.2f minutes", travelTime)
//            arOverlayView.travelDistanceLabel.text = String(format: "Travel distance: %.2f miles", travelDistance)
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    
//    
//    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
//        if let polyline = overlay as? MKPolyline {
//            let renderer = MKPolylineRenderer(polyline: polyline)
//            renderer.strokeColor = .blue
//            renderer.lineWidth = 3
//            return renderer
//        }
//        return MKOverlayRenderer()
//    }
//    
//    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                guard let currentCoordinate = currentCoordinate else { return }
//                
//                let distance = calculateDistance(from: geoAnchor.coordinate, to: currentCoordinate)
//                
//                // print or debug values here
//                print("Distance: \(distance), GeoAnchor Coordinate: \(geoAnchor.coordinate)")
//                
//                if let annotationNode = loadImageAnnotation(named: "restroom") {  // Replace "Image_Name" with the name of your image file
//                    let anchorNode = SCNNode()
//                                        anchorNode.addChildNode(annotationNode)
//                                        anchorNode.simdTransform = geoAnchor.transform // Set the transform of the anchor node to the anchor's transform
//                                        
//                                        // Add the node to the scene
//                                        sceneLocationView.scene.rootNode.addChildNode(anchorNode)
//
//                                        // Store the anchor-to-node mapping
//                                        anchorNodeDictionary[geoAnchor] = anchorNode
//                                    }
//                                }
//                            }
//
//                            // Only start the animation after all anchors have been added
//                            if anchors.count == self.anchors.count {
//                                animateObjectOnRoute()
//                            }
//                        }
//    func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
//        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
//        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
//        return from.distance(from: to) // in meters
//    }
//    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor updated: \(geoAnchor)")
//            }
//        }
//    }
//    
//    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor removed: \(geoAnchor)")
//                
//                sceneLocationView.scene.rootNode.enumerateChildNodes { node, _ in
//                    node.removeFromParentNode()
//                }
//            }
//        }
//    }
//}
//


//import UIKit
//import MapKit
//import CoreLocation
//import ARCL
//import ARKit
//
//struct Restroom {
//    let title: String
//    let latitude: Double
//    let longitude: Double
//}
//
//struct GeoJSON: Codable {
//    let features: [Feature]
//}
//
//struct Feature: Codable {
//    let geometry: Geometry
//}
//
//struct Geometry: Codable {
//    let coordinates: [Double]
//}
//
//
//class RestroomAnnotation: NSObject, MKAnnotation {
//    let title: String?
//    let coordinate: CLLocationCoordinate2D
//
//    init(title: String, coordinate: CLLocationCoordinate2D) {
//        self.title = title
//        self.coordinate = coordinate
//    }
//}
//class AROverlayView: UIView {
//    let travelTimeLabel: UILabel
//    let travelDistanceLabel: UILabel
//
//    override init(frame: CGRect) {
//        travelTimeLabel = UILabel()
//        travelDistanceLabel = UILabel()
//
//        super.init(frame: frame)
//
//        // Set some dummy text for initial display
//        travelTimeLabel.text = "Initial travel time"
//        travelDistanceLabel.text = "Initial travel distance"
//
//        // Set text color, font and shadow
//        let customFont = UIFont.boldSystemFont(ofSize: 18) // Change the size to fit your needs
//        let textColor = UIColor.yellow
//        let shadow = NSShadow()
//        shadow.shadowColor = UIColor.black
//        shadow.shadowOffset = CGSize(width: 1, height: 1)
//
//        travelTimeLabel.font = customFont
//        travelTimeLabel.textColor = textColor
//        travelTimeLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelTimeLabel.shadowOffset = shadow.shadowOffset
//
//        travelDistanceLabel.font = customFont
//        travelDistanceLabel.textColor = textColor
//        travelDistanceLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelDistanceLabel.shadowOffset = shadow.shadowOffset
//
//        // Add labels to the AR overlay view
//        self.addSubview(travelTimeLabel)
//        self.addSubview(travelDistanceLabel)
//
//        // Layout configuration code...
//        // Make sure the labels are properly laid out inside the view.
//        travelTimeLabel.translatesAutoresizingMaskIntoConstraints = false
//        travelDistanceLabel.translatesAutoresizingMaskIntoConstraints = false
//        
//        // Set up constraints for labels to display them correctly
//        NSLayoutConstraint.activate([
//            travelTimeLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelTimeLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelTimeLabel.topAnchor.constraint(equalTo: self.topAnchor),
//            travelTimeLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            
//            travelDistanceLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelDistanceLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelDistanceLabel.topAnchor.constraint(equalTo: travelTimeLabel.bottomAnchor),
//            travelDistanceLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            travelDistanceLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor), // Set the bottom constraint
//        ])
//
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//
//class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
//    
//    var sceneLocationView = SceneLocationView()
//    var mapView = MKMapView()
//    let locationManager = CLLocationManager()
//    var currentCoordinate: CLLocationCoordinate2D?
//    var restrooms: [Restroom] = []
//    var currentRoute: MKRoute?
//    var anchors: [ARGeoAnchor] = []
//    var arOverlayView: AROverlayView?
//    var previousPoint: ARGeoAnchor?
//    var currentAnnotationNode: LocationAnnotationNode?
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Setting up the delegates
//        mapView.delegate = self
//        
//        let configuration = ARWorldTrackingConfiguration()
//        configuration.worldAlignment = .gravityAndHeading
//        
//        // Setting up the AR view
//        sceneLocationView.run()
//        sceneLocationView.session.run(configuration)
//        sceneLocationView.pointOfView?.camera?.zFar = 1000  // Set the far clipping plane to 1000 meters
//        
//        // Setting up the Map view
//        configureLocationServices()
//        loadRestroomLocations()
//        
//        // Adding both the Map and AR view to a stack view and add it to the view hierarchy
//        let stackView = UIStackView(arrangedSubviews: [sceneLocationView, mapView])
//        stackView.axis = .vertical
//        stackView.distribution = .fillEqually
//        stackView.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(stackView)
//        
//        // Constraints for stack view to fill the entire view
//        NSLayoutConstraint.activate([
//            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            stackView.topAnchor.constraint(equalTo: view.topAnchor),
//            stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//        ])
//        
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            sceneLocationView.addSubview(arOverlayView)
//        }
//        locationManager.delegate = self
//            locationManager.requestWhenInUseAuthorization()
//        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
//            locationManager.startUpdatingLocation()
//    }
//    
//    
//    func loadImageAnnotation(named: String) -> SCNNode? {
//        let annotationImage = UIImage(named: named)
//        let annotationPlane = SCNPlane(width: 1.0, height: 1.0)
//        annotationPlane.firstMaterial?.diffuse.contents = annotationImage
//        let annotationNode = SCNNode(geometry: annotationPlane)
//        annotationNode.eulerAngles.x = -.pi / 2  // Correct the orientation of the image
//        return annotationNode
//    }
//    
//    
//    
//    func configureLocationServices() {
//        locationManager.delegate = self
//        let authorizationStatus = locationManager.authorizationStatus  // Access the property directly
//        if authorizationStatus == .notDetermined {
//            locationManager.requestWhenInUseAuthorization()
//        } else if authorizationStatus == .authorizedAlways || authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: locationManager)
//        }
//    }
//    
//    func beginLocationUpdates(locationManager: CLLocationManager) {
//        mapView.showsUserLocation = true
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.startUpdatingLocation()
//    }
//    
//    func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
//        let zoomRegion = MKCoordinateRegion.init(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
//        mapView.setRegion(zoomRegion, animated: true)
//    }
//    
//    func addRestroomLocations() {
//        restrooms.forEach { restroom in
//            let annotation = RestroomAnnotation(title: restroom.title, coordinate: CLLocationCoordinate2D(latitude: restroom.latitude, longitude: restroom.longitude))
//            mapView.addAnnotation(annotation)
//        }
//    }
//    
//    
//    func loadRestroomLocations() {
//        guard let url = Bundle.main.url(forResource: "export", withExtension: "geojson") else { return }
//        do {
//            let data = try Data(contentsOf: url)
//            let geoJSON = try JSONDecoder().decode(GeoJSON.self, from: data)
//            geoJSON.features.forEach { feature in
//                let title = "Restroom"
//                let latitude = feature.geometry.coordinates[1]
//                let longitude = feature.geometry.coordinates[0]
//                let restroom = Restroom(title: title, latitude: latitude, longitude: longitude)
//                restrooms.append(restroom)
//            }
//            addRestroomLocations()
//        } catch {
//            print(error)
//        }
//    }
//    
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        guard let latestLocation = locations.first else { return }
//        if currentCoordinate == nil {
//            zoomToLatestLocation(with: latestLocation.coordinate)
//        }
//        
//        currentCoordinate = latestLocation.coordinate
//        
//        // If there's a current destination, regenerate the route
//        if let destination = mapView.selectedAnnotations.first?.coordinate {
//            generateRoute(to: destination)
//        }
//    }
//    
//    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
//        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: manager)
//        }
//    }
//    
//    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//        guard let coordinate = view.annotation?.coordinate else { return }
//        
//        // Clear the previous path if any
//        if let currentRoute = self.currentRoute {
//            self.mapView.removeOverlay(currentRoute.polyline)
//            self.currentRoute = nil
//        }
//        
//        if let arOverlayView = arOverlayView {
//            arOverlayView.removeFromSuperview()
//            self.arOverlayView = nil
//        }
//        
//        // Deselect all annotations
//        let allAnnotations = mapView.annotations
//        allAnnotations.forEach { mapView.deselectAnnotation($0, animated: false) }
//        
//        // Clear the previous anchor if any
//        sceneLocationView.removeAllNodes()
//        
//        // Place the new AR node
//        let location = CLLocation(coordinate: coordinate, altitude: 10)
//        let image = UIImage(named: "restroom")!
//        let annotationNode = LocationAnnotationNode(location: location, image: image)
//        sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
//        
//        generateRoute(to: coordinate)
//    }
//    
//    
//    func addRouteStepDirections() {
//        guard let route = currentRoute else { return }
//
//        // Make sure we have a valid current location
//        guard let currentLocation = locationManager.location else { return }
//
//        for (_, step) in route.steps.enumerated() {
//            let points = step.polyline.points()
//            let coordinates = (0..<step.polyline.pointCount).map { points[$0].coordinate }
//            for i in 0..<coordinates.count-1 {
//                let startCoordinate = coordinates[i]
//                let endCoordinate = coordinates[i+1]
//
//                let startLocation = CLLocation(latitude: startCoordinate.latitude, longitude: startCoordinate.longitude)
//
//                // Create a SCNText geometry with the string "This way >>>"
//                let text = SCNText(string: ">>>>>>>>", extrusionDepth: 0.2)
//                text.firstMaterial?.diffuse.contents = UIColor.red
//
//                let textNode = SCNNode(geometry: text)
//                textNode.position = SCNVector3Make(0, 0, 0)  // Positioning the text at ground level
//
//                // Orient the node to point from the current point to the next point
//                let bearing = calculateBearing(from: startCoordinate, to: endCoordinate)
//
//                // Get the user's current heading
//                let userHeading = currentLocation.course
//
//                // Calculate the relative bearing from the user's current heading to the next waypoint
//                let relativeBearing = bearing - Float(userHeading)
//                textNode.eulerAngles.y = relativeBearing
//
//                let locationNode = LocationNode(location: startLocation)
//                locationNode.addChildNode(textNode)
//
//                sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: locationNode)
//            }
//        }
//    }
//
//
//    func calculateBearing(from start: CLLocationCoordinate2D, to end: CLLocationCoordinate2D) -> Float {
//        let lat1 = start.latitude * .pi / 180
//        let lon1 = start.longitude * .pi / 180
//        
//        let lat2 = end.latitude * .pi / 180
//        let lon2 = end.longitude * .pi / 180
//        
//        let dLon = lon2 - lon1
//        
//        let y = sin(dLon) * cos(lat2)
//        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
//        let bearing = atan2(y, x)
//        
//        return Float(bearing)
//    }
//
//
//
//    
//    func generateRoute(to destination: CLLocationCoordinate2D) {
//        guard let sourceCoordinate = currentCoordinate else { return }
//        
//        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
//        let destinationPlacemark = MKPlacemark(coordinate: destination)
//        
//        let sourceItem = MKMapItem(placemark: sourcePlacemark)
//        let destinationItem = MKMapItem(placemark: destinationPlacemark)
//        
//        let directionRequest = MKDirections.Request()
//        directionRequest.source = sourceItem
//        directionRequest.destination = destinationItem
//        directionRequest.transportType = .automobile
//        
//        let directions = MKDirections(request: directionRequest)
//        directions.calculate { [weak self] (response, error) in
//            guard let response = response else { return } // handle error
//            self?.currentRoute = response.routes[0]
//            self?.mapView.addOverlay((self?.currentRoute!.polyline)!)
//            
//            // Retrieve the travel time and distance
//            let travelTime = response.routes[0].expectedTravelTime / 60
//            let travelDistance = response.routes[0].distance / 1609.34
//            
//            // Start AR session with the travel information
//            self?.startARSession(to: destination, travelTime: travelTime, travelDistance: travelDistance)
//            self?.addRouteStepDirections()
//        }
//    }
//    
//
//    func startARSession(to destination: CLLocationCoordinate2D, travelTime: TimeInterval, travelDistance: CLLocationDistance) {
//        // Create and set up AR overlay view
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            // Display the raw `travelTime` and `travelDistance` values.
//            arOverlayView.travelTimeLabel.text = String(format: " Time: %.2f minutes", travelTime)
//            arOverlayView.travelDistanceLabel.text = String(format: "Travel distance: %.2f miles", travelDistance)
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    
//    
//    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
//        if let polyline = overlay as? MKPolyline {
//            let renderer = MKPolylineRenderer(polyline: polyline)
//            renderer.strokeColor = .blue
//            renderer.lineWidth = 3
//            return renderer
//        }
//        return MKOverlayRenderer()
//    }
//    
//    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                guard let currentCoordinate = currentCoordinate else { return }
//                
//                let distance = calculateDistance(from: geoAnchor.coordinate, to: currentCoordinate)
//                
//                // print or debug values here
//                print("Distance: \(distance), GeoAnchor Coordinate: \(geoAnchor.coordinate)")
//                
//                if let annotationNode = loadImageAnnotation(named: "restroom") {  // Replace "Image_Name" with the name of your image file
//                    let anchorNode = SCNNode()
//                    anchorNode.addChildNode(annotationNode)
//                    anchorNode.simdTransform = geoAnchor.transform // Set the transform of the anchor node to the anchor's transform
//                    
//                    // Add the node to the scene
//                    sceneLocationView.scene.rootNode.addChildNode(anchorNode)
//                }
//            }
//        }
//    }
//    func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
//        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
//        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
//        return from.distance(from: to) // in meters
//    }
//    
//    
//    
//    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor updated: \(geoAnchor)")
//            }
//        }
//    }
//    
//    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor removed: \(geoAnchor)")
//                
//                sceneLocationView.scene.rootNode.enumerateChildNodes { node, _ in
//                    node.removeFromParentNode()
//                }
//            }
//        }
//    }
//}




//import UIKit
//import MapKit
//import CoreLocation
//import ARCL
//import ARKit
//
//struct Restroom {
//    let title: String
//    let latitude: Double
//    let longitude: Double
//}
//
//struct GeoJSON: Codable {
//    let features: [Feature]
//}
//
//struct Feature: Codable {
//    let geometry: Geometry
//}
//
//struct Geometry: Codable {
//    let coordinates: [Double]
//}
//
//
//class RestroomAnnotation: NSObject, MKAnnotation {
//    let title: String?
//    let coordinate: CLLocationCoordinate2D
//
//    init(title: String, coordinate: CLLocationCoordinate2D) {
//        self.title = title
//        self.coordinate = coordinate
//    }
//}
//class AROverlayView: UIView {
//    let travelTimeLabel: UILabel
//    let travelDistanceLabel: UILabel
//
//    override init(frame: CGRect) {
//        travelTimeLabel = UILabel()
//        travelDistanceLabel = UILabel()
//
//        super.init(frame: frame)
//
//        // Set some dummy text for initial display
//        travelTimeLabel.text = "Initial travel time"
//        travelDistanceLabel.text = "Initial travel distance"
//
//        // Set text color, font and shadow
//        let customFont = UIFont.boldSystemFont(ofSize: 18) // Change the size to fit your needs
//        let textColor = UIColor.yellow
//        let shadow = NSShadow()
//        shadow.shadowColor = UIColor.black
//        shadow.shadowOffset = CGSize(width: 1, height: 1)
//
//        travelTimeLabel.font = customFont
//        travelTimeLabel.textColor = textColor
//        travelTimeLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelTimeLabel.shadowOffset = shadow.shadowOffset
//
//        travelDistanceLabel.font = customFont
//        travelDistanceLabel.textColor = textColor
//        travelDistanceLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelDistanceLabel.shadowOffset = shadow.shadowOffset
//
//        // Add labels to the AR overlay view
//        self.addSubview(travelTimeLabel)
//        self.addSubview(travelDistanceLabel)
//
//        // Layout configuration code...
//        // Make sure the labels are properly laid out inside the view.
//        travelTimeLabel.translatesAutoresizingMaskIntoConstraints = false
//        travelDistanceLabel.translatesAutoresizingMaskIntoConstraints = false
//        
//        // Set up constraints for labels to display them correctly
//        NSLayoutConstraint.activate([
//            travelTimeLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelTimeLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelTimeLabel.topAnchor.constraint(equalTo: self.topAnchor),
//            travelTimeLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            
//            travelDistanceLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelDistanceLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelDistanceLabel.topAnchor.constraint(equalTo: travelTimeLabel.bottomAnchor),
//            travelDistanceLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            travelDistanceLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor), // Set the bottom constraint
//        ])
//
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//class SphereLocationNode: LocationNode {
//    var sphereNode: SCNNode?
//    
//    init(location: CLLocation?, sphereNode: SCNNode) {
//        super.init(location: location)
//        self.sphereNode = sphereNode
//        addChildNode(sphereNode)
//    }
//    
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//
//
//class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
//    
//    var sceneLocationView = SceneLocationView()
//    var mapView = MKMapView()
//    let locationManager = CLLocationManager()
//    var currentCoordinate: CLLocationCoordinate2D?
//    var restrooms: [Restroom] = []
//    var currentRoute: MKRoute?
//    var anchors: [ARGeoAnchor] = []
//    var arOverlayView: AROverlayView?
//    
//    var currentAnnotationNode: LocationAnnotationNode?
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Setting up the delegates
//        mapView.delegate = self
//        
//        let configuration = ARWorldTrackingConfiguration()
//        configuration.worldAlignment = .gravityAndHeading
//        
//        // Setting up the AR view
//        sceneLocationView.run()
//        sceneLocationView.session.run(configuration)
//        sceneLocationView.pointOfView?.camera?.zFar = 1000  // Set the far clipping plane to 1000 meters
//        
//        // Setting up the Map view
//        configureLocationServices()
//        loadRestroomLocations()
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//
//                // Request user permission for location services
//                locationManager.requestWhenInUseAuthorization()
//
//                // Set ViewController to respond to location updates
//                locationManager.delegate = self
//
//                // Start updating location
//                locationManager.startUpdatingLocation()
//        
//        // Adding both the Map and AR view to a stack view and add it to the view hierarchy
//        let stackView = UIStackView(arrangedSubviews: [sceneLocationView, mapView])
//        stackView.axis = .vertical
//        stackView.distribution = .fillEqually
//        stackView.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(stackView)
//        
//        // Constraints for stack view to fill the entire view
//        NSLayoutConstraint.activate([
//            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            stackView.topAnchor.constraint(equalTo: view.topAnchor),
//            stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//        ])
//        
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    
//    
//    func loadImageAnnotation(named: String) -> SCNNode? {
//        let annotationImage = UIImage(named: named)
//        let annotationPlane = SCNPlane(width: 1.0, height: 1.0)
//        annotationPlane.firstMaterial?.diffuse.contents = annotationImage
//        let annotationNode = SCNNode(geometry: annotationPlane)
//        annotationNode.eulerAngles.x = -.pi / 2  // Correct the orientation of the image
//        return annotationNode
//    }
//    
//    
//    
//    func configureLocationServices() {
//        locationManager.delegate = self
//        let authorizationStatus = locationManager.authorizationStatus  // Access the property directly
//        if authorizationStatus == .notDetermined {
//            locationManager.requestWhenInUseAuthorization()
//        } else if authorizationStatus == .authorizedAlways || authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: locationManager)
//        }
//    }
//    
//    func beginLocationUpdates(locationManager: CLLocationManager) {
//        mapView.showsUserLocation = true
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.startUpdatingLocation()
//    }
//    
//    func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
//        let zoomRegion = MKCoordinateRegion.init(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
//        mapView.setRegion(zoomRegion, animated: true)
//    }
//    
//    func addRestroomLocations() {
//        restrooms.forEach { restroom in
//            let annotation = RestroomAnnotation(title: restroom.title, coordinate: CLLocationCoordinate2D(latitude: restroom.latitude, longitude: restroom.longitude))
//            mapView.addAnnotation(annotation)
//        }
//    }
//    
//    
//    func loadRestroomLocations() {
//        guard let url = Bundle.main.url(forResource: "export", withExtension: "geojson") else { return }
//        do {
//            let data = try Data(contentsOf: url)
//            let geoJSON = try JSONDecoder().decode(GeoJSON.self, from: data)
//            geoJSON.features.forEach { feature in
//                let title = "Restroom"
//                let latitude = feature.geometry.coordinates[1]
//                let longitude = feature.geometry.coordinates[0]
//                let restroom = Restroom(title: title, latitude: latitude, longitude: longitude)
//                restrooms.append(restroom)
//            }
//            addRestroomLocations()
//        } catch {
//            print(error)
//        }
//    }
//    
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        guard let latestLocation = locations.first else { return }
//        if currentCoordinate == nil {
//            zoomToLatestLocation(with: latestLocation.coordinate)
//        }
//        
//        currentCoordinate = latestLocation.coordinate
//        
//        // If there's a current destination, regenerate the route
//        if let destination = mapView.selectedAnnotations.first?.coordinate {
//            generateRoute(to: destination)
//        }
//    }
//    
//    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
//        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: manager)
//        }
//    }
//    
//    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//        guard let coordinate = view.annotation?.coordinate else { return }
//        
//        // Clear the previous path if any
//        if let currentRoute = self.currentRoute {
//            self.mapView.removeOverlay(currentRoute.polyline)
//            self.currentRoute = nil
//        }
//        
//        if let arOverlayView = arOverlayView {
//            arOverlayView.removeFromSuperview()
//            self.arOverlayView = nil
//        }
//        
//        // Deselect all annotations
//        let allAnnotations = mapView.annotations
//        allAnnotations.forEach { mapView.deselectAnnotation($0, animated: false) }
//        
//        // Clear the previous anchor if any
//        sceneLocationView.removeAllNodes()
//        
//        // Place the new AR node
//        let location = CLLocation(coordinate: coordinate, altitude: 10)
//        let image = UIImage(named: "restroom")!
//        let annotationNode = LocationAnnotationNode(location: location, image: image)
//        sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
//        
//        generateRoute(to: coordinate)
//    }
//    
//    
//    func generateRoute(to destination: CLLocationCoordinate2D) {
//        guard let sourceCoordinate = currentCoordinate else { return }
//
//        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
//        let destinationPlacemark = MKPlacemark(coordinate: destination)
//
//        let sourceItem = MKMapItem(placemark: sourcePlacemark)
//        let destinationItem = MKMapItem(placemark: destinationPlacemark)
//
//        let directionRequest = MKDirections.Request()
//        directionRequest.source = sourceItem
//        directionRequest.destination = destinationItem
//        directionRequest.transportType = .automobile
//
//        let directions = MKDirections(request: directionRequest)
//        directions.calculate { [weak self] (response, error) in
//            guard let response = response else { return } // handle error
//            self?.currentRoute = response.routes[0]
//            self?.mapView.addOverlay((self?.currentRoute!.polyline)!)
//
//            // Retrieve the travel time and distance
//            let travelTime = response.routes[0].expectedTravelTime / 60
//            let travelDistance = response.routes[0].distance / 1609.34
//
//            // Start AR session with the travel information
//            self?.startARSession(to: destination, travelTime: travelTime, travelDistance: travelDistance)
//
//            // Generate the AR spheres
//            self?.generateARSpheres(for: (self?.currentRoute!.polyline.points())!, count: self?.currentRoute!.polyline.pointCount ?? 0)
//        }
//    }
//
//    func generateARSpheres(for points: UnsafePointer<MKMapPoint>, count: Int) {
//        for i in 0..<count {
//            let mapPoint = points[i]
//            let coordinate = mapPoint.coordinate
//
//            // Create ARGeoAnchor for each point
//            let geoAnchor = ARGeoAnchor(name: "BreadCrumb_\(i)", coordinate: coordinate)
//
//            // Add the anchor to AR session
//            sceneLocationView.session.add(anchor: geoAnchor)
//
//            // Add a sphere for each anchor
//            let sphereNode = createSphereNode()
//
//            // Assign a unique name to each sphere node
//            sphereNode.name = "BreadCrumb_\(i)"
//
//            // Create a SphereLocationNode with the sphere
//            let locationSphereNode = SphereLocationNode(location: CLLocation(coordinate: coordinate, altitude: 10), sphereNode: sphereNode)
//
//            // Add the node to the ARGeoAnchor
//            sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: locationSphereNode)
//        }
//    }
//
//
//    func createSphereNode() -> SCNNode {
//        let sphere = SCNSphere(radius: 0.1)
//        let sphereNode = SCNNode(geometry: sphere)
//        sphereNode.geometry?.firstMaterial?.diffuse.contents = UIColor.red
//        return sphereNode
//    }
//    
//    func startARSession(to destination: CLLocationCoordinate2D, travelTime: TimeInterval, travelDistance: CLLocationDistance) {
//        // Create and set up AR overlay view
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            // Display the raw `travelTime` and `travelDistance` values.
//            arOverlayView.travelTimeLabel.text = String(format: " Time: %.2f minutes", travelTime)
//            arOverlayView.travelDistanceLabel.text = String(format: "Travel distance: %.2f miles", travelDistance)
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    
//    
//    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
//        if let polyline = overlay as? MKPolyline {
//            let renderer = MKPolylineRenderer(polyline: polyline)
//            renderer.strokeColor = .blue
//            renderer.lineWidth = 3
//            return renderer
//        }
//        return MKOverlayRenderer()
//    }
//    
//    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                guard let currentCoordinate = currentCoordinate else { return }
//                
//                let distance = calculateDistance(from: geoAnchor.coordinate, to: currentCoordinate)
//                
//                // print or debug values here
//                print("Distance: \(distance), GeoAnchor Coordinate: \(geoAnchor.coordinate)")
//                
//                if let annotationNode = loadImageAnnotation(named: "restroom") {  // Replace "Image_Name" with the name of your image file
//                    let anchorNode = SCNNode()
//                    anchorNode.addChildNode(annotationNode)
//                    anchorNode.simdTransform = geoAnchor.transform // Set the transform of the anchor node to the anchor's transform
//                    
//                    // Add the node to the scene
//                    sceneLocationView.scene.rootNode.addChildNode(anchorNode)
//                }
//            }
//        }
//    }
//    
//    
//    
//    
//    
//    
//    func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
//        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
//        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
//        return from.distance(from: to) // in meters
//    }
//    
//    
//    
//    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor updated: \(geoAnchor)")
//            }
//        }
//    }
//    
//    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor removed: \(geoAnchor)")
//                
//                sceneLocationView.scene.rootNode.enumerateChildNodes { node, _ in
//                    node.removeFromParentNode()
//                }
//            }
//        }
//    }
//}


//import UIKit
//import MapKit
//import CoreLocation
//import ARCL
//import ARKit
//
//struct Restroom {
//    let title: String
//    let latitude: Double
//    let longitude: Double
//}
//
//struct GeoJSON: Codable {
//    let features: [Feature]
//}
//
//struct Feature: Codable {
//    let geometry: Geometry
//}
//
//struct Geometry: Codable {
//    let coordinates: [Double]
//}
//
//
//class RestroomAnnotation: NSObject, MKAnnotation {
//    let title: String?
//    let coordinate: CLLocationCoordinate2D
//
//    init(title: String, coordinate: CLLocationCoordinate2D) {
//        self.title = title
//        self.coordinate = coordinate
//    }
//}
//class AROverlayView: UIView {
//    let travelTimeLabel: UILabel
//    let travelDistanceLabel: UILabel
//
//    override init(frame: CGRect) {
//        travelTimeLabel = UILabel()
//        travelDistanceLabel = UILabel()
//
//        super.init(frame: frame)
//
//        // Set some dummy text for initial display
//        travelTimeLabel.text = "Initial travel time"
//        travelDistanceLabel.text = "Initial travel distance"
//
//        // Set text color, font and shadow
//        let customFont = UIFont.boldSystemFont(ofSize: 18) // Change the size to fit your needs
//        let textColor = UIColor.yellow
//        let shadow = NSShadow()
//        shadow.shadowColor = UIColor.black
//        shadow.shadowOffset = CGSize(width: 1, height: 1)
//
//        travelTimeLabel.font = customFont
//        travelTimeLabel.textColor = textColor
//        travelTimeLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelTimeLabel.shadowOffset = shadow.shadowOffset
//
//        travelDistanceLabel.font = customFont
//        travelDistanceLabel.textColor = textColor
//        travelDistanceLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelDistanceLabel.shadowOffset = shadow.shadowOffset
//
//        // Add labels to the AR overlay view
//        self.addSubview(travelTimeLabel)
//        self.addSubview(travelDistanceLabel)
//
//        // Layout configuration code...
//        // Make sure the labels are properly laid out inside the view.
//        travelTimeLabel.translatesAutoresizingMaskIntoConstraints = false
//        travelDistanceLabel.translatesAutoresizingMaskIntoConstraints = false
//        
//        // Set up constraints for labels to display them correctly
//        NSLayoutConstraint.activate([
//            travelTimeLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelTimeLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelTimeLabel.topAnchor.constraint(equalTo: self.topAnchor),
//            travelTimeLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            
//            travelDistanceLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelDistanceLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelDistanceLabel.topAnchor.constraint(equalTo: travelTimeLabel.bottomAnchor),
//            travelDistanceLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            travelDistanceLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor), // Set the bottom constraint
//        ])
//
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//
//class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
//    
//    var sceneLocationView = SceneLocationView()
//    var mapView = MKMapView()
//    let locationManager = CLLocationManager()
//    var currentCoordinate: CLLocationCoordinate2D?
//    var restrooms: [Restroom] = []
//    var currentRoute: MKRoute?
//    var anchors: [ARGeoAnchor] = []
//    var arOverlayView: AROverlayView?
//    var breadcrumbs: [LocationAnnotationNode] = []
//    var currentAnnotationNode: LocationAnnotationNode?
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Setting up the delegates
//        mapView.delegate = self
//        locationManager.delegate = self
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.requestWhenInUseAuthorization()
//        locationManager.startUpdatingLocation()
//        
//        let configuration = ARWorldTrackingConfiguration()
//        configuration.worldAlignment = .gravityAndHeading
//        
//        // Setting up the AR view
//        sceneLocationView.run()
//        sceneLocationView.session.run(configuration)
//        sceneLocationView.pointOfView?.camera?.zFar = 1000  // Set the far clipping plane to 1000 meters
//        
//        // Setting up the Map view
//        configureLocationServices()
//        loadRestroomLocations()
//        
//        // Adding both the Map and AR view to a stack view and add it to the view hierarchy
//        let stackView = UIStackView(arrangedSubviews: [sceneLocationView, mapView])
//        stackView.axis = .vertical
//        stackView.distribution = .fillEqually
//        stackView.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(stackView)
//        
//        // Constraints for stack view to fill the entire view
//        NSLayoutConstraint.activate([
//            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            stackView.topAnchor.constraint(equalTo: view.topAnchor),
//            stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//        ])
//        
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            sceneLocationView.addSubview(arOverlayView)
//       
//        }
//    }
//    
//    
//    func loadImageAnnotation(named: String) -> SCNNode? {
//        let annotationImage = UIImage(named: named)
//        let annotationPlane = SCNPlane(width: 1.0, height: 1.0)
//        annotationPlane.firstMaterial?.diffuse.contents = annotationImage
//        let annotationNode = SCNNode(geometry: annotationPlane)
//        annotationNode.eulerAngles.x = -.pi / 2  // Correct the orientation of the image
//        return annotationNode
//    }
//    
//    
//    
//    func configureLocationServices() {
//        locationManager.delegate = self
//        let authorizationStatus = locationManager.authorizationStatus  // Access the property directly
//        if authorizationStatus == .notDetermined {
//            locationManager.requestWhenInUseAuthorization()
//        } else if authorizationStatus == .authorizedAlways || authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: locationManager)
//        }
//    }
//    
//    func beginLocationUpdates(locationManager: CLLocationManager) {
//        mapView.showsUserLocation = true
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.startUpdatingLocation()
//    }
//    
//    func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
//        let zoomRegion = MKCoordinateRegion.init(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
//        mapView.setRegion(zoomRegion, animated: true)
//    }
//    
//    func addRestroomLocations() {
//        restrooms.forEach { restroom in
//            let annotation = RestroomAnnotation(title: restroom.title, coordinate: CLLocationCoordinate2D(latitude: restroom.latitude, longitude: restroom.longitude))
//            mapView.addAnnotation(annotation)
//        }
//    }
//    
//    
//    func loadRestroomLocations() {
//        guard let url = Bundle.main.url(forResource: "export", withExtension: "geojson") else { return }
//        do {
//            let data = try Data(contentsOf: url)
//            let geoJSON = try JSONDecoder().decode(GeoJSON.self, from: data)
//            geoJSON.features.forEach { feature in
//                let title = "Restroom"
//                let latitude = feature.geometry.coordinates[1]
//                let longitude = feature.geometry.coordinates[0]
//                let restroom = Restroom(title: title, latitude: latitude, longitude: longitude)
//                restrooms.append(restroom)
//            }
//            addRestroomLocations()
//        } catch {
//            print(error)
//        }
//    }
//    
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        guard let latestLocation = locations.first else { return }
//
//        // If currentCoordinate is nil, it means it's the first update, so we zoom to the latest location
//        if currentCoordinate == nil {
//            zoomToLatestLocation(with: latestLocation.coordinate)
//        }
//
//        // Updating currentCoordinate
//        currentCoordinate = latestLocation.coordinate
//
//        // If there's a current destination, regenerate the route
//        if let destination = mapView.selectedAnnotations.first?.coordinate {
//            generateRoute(to: destination)
//        }
//        
//        // Updating breadcrumbs
//        updateBreadcrumbs()
//    }
//
//    
//    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
//        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: manager)
//        }
//    }
//    
//    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//        guard let coordinate = view.annotation?.coordinate else { return }
//        
//        // Clear the previous path if any
//        if let currentRoute = self.currentRoute {
//            self.mapView.removeOverlay(currentRoute.polyline)
//            self.currentRoute = nil
//        }
//        
//        if let arOverlayView = arOverlayView {
//            arOverlayView.removeFromSuperview()
//            self.arOverlayView = nil
//        }
//        
//        // Deselect all annotations
//        let allAnnotations = mapView.annotations
//        allAnnotations.forEach { mapView.deselectAnnotation($0, animated: false) }
//        
//        // Clear the previous anchor if any
//        sceneLocationView.removeAllNodes()
//        
//        // Place the new AR node
//        let location = CLLocation(coordinate: coordinate, altitude: 10)
//        let image = UIImage(named: "restroom")!
//        let annotationNode = LocationAnnotationNode(location: location, image: image)
//        sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
//        
//        generateRoute(to: coordinate)
//    }
//    func generateBreadcrumbs(from start: CLLocationCoordinate2D, to end: CLLocationCoordinate2D) {
//        // Clear old breadcrumbs
//        breadcrumbs.forEach { breadcrumb in
//            sceneLocationView.removeLocationNode(locationNode: breadcrumb)
//        }
//        breadcrumbs.removeAll()
//
//        // Calculate vector from start to end
//        let dx = end.latitude - start.latitude
//        let dy = end.longitude - start.longitude
//
//        // Add breadcrumbs
//        for i in 1...10 {
//            let breadcrumbCoordinate = CLLocationCoordinate2D(
//                latitude: start.latitude + dx * Double(i) / 10,
//                longitude: start.longitude + dy * Double(i) / 10
//            )
//            let breadcrumbLocation = CLLocation(coordinate: breadcrumbCoordinate, altitude: -0.75)
//            let breadcrumbImage = UIImage(named: "Geolocation")!
//            let breadcrumbNode = LocationAnnotationNode(location: breadcrumbLocation, image: breadcrumbImage)
//            breadcrumbs.append(breadcrumbNode)
//            sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: breadcrumbNode)
//        }
//    }
//    
//    func generateRoute(to destination: CLLocationCoordinate2D) {
//        guard let sourceCoordinate = currentCoordinate else { return }
//        
//        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
//        let destinationPlacemark = MKPlacemark(coordinate: destination)
//        
//        let sourceItem = MKMapItem(placemark: sourcePlacemark)
//        let destinationItem = MKMapItem(placemark: destinationPlacemark)
//        
//        let directionRequest = MKDirections.Request()
//        directionRequest.source = sourceItem
//        directionRequest.destination = destinationItem
//        directionRequest.transportType = .automobile
//        
//        let directions = MKDirections(request: directionRequest)
//        directions.calculate { [weak self] (response, error) in
//            guard let response = response else { return } // handle error
//            self?.currentRoute = response.routes[0]
//            self?.mapView.addOverlay((self?.currentRoute!.polyline)!)
//            
//            // Retrieve the travel time and distance
//            let travelTime = response.routes[0].expectedTravelTime / 60
//            let travelDistance = response.routes[0].distance / 1609.34
//            
//            // Set travel time and distance labels
//            self?.arOverlayView?.travelTimeLabel.text = String(format: " Time: %.2f minutes", travelTime)
//            self?.arOverlayView?.travelDistanceLabel.text = String(format: "Travel distance: %.2f miles", travelDistance)
//            guard let firstBreadcrumbCoordinate = response.routes[0].steps.first?.polyline.coordinate else { return }
//                    self?.generateBreadcrumbs(from: sourceCoordinate, to: firstBreadcrumbCoordinate)
//                }
//            }
//    
//
//    
//    func startARSession(to destination: CLLocationCoordinate2D, travelTime: TimeInterval, travelDistance: CLLocationDistance) {
//        // Create and set up AR overlay view
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            // Display the raw `travelTime` and `travelDistance` values.
//            arOverlayView.travelTimeLabel.text = String(format: " Time: %.2f minutes", travelTime)
//            arOverlayView.travelDistanceLabel.text = String(format: "Travel distance: %.2f miles", travelDistance)
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    func updateBreadcrumbs() {
//        guard let currentLocation = locationManager.location,
//                let steps = currentRoute?.steps else { return }
//
//            let currentCoordinate = currentLocation.coordinate
//
//        // If the user has crossed this breadcrumb
//        let breadcrumbToRemoveIndices = breadcrumbs.indices.filter { index in
//            let breadcrumbCoordinate = breadcrumbs[index].location.coordinate
//            return distance(from: currentCoordinate, to: breadcrumbCoordinate) < 1
//        }
//
//        // Remove old breadcrumbs
//        breadcrumbToRemoveIndices.reversed().forEach { index in
//            let oldBreadcrumb = breadcrumbs.remove(at: index)
//            sceneLocationView.removeLocationNode(locationNode: oldBreadcrumb)
//        }
//
//        // If we removed any breadcrumb, generate new breadcrumbs 10 meters ahead
//        if !breadcrumbToRemoveIndices.isEmpty {
//            guard let lastBreadcrumbCoordinate = breadcrumbs.last?.location.coordinate else { return }
//            let remainingDistance = distance(from: currentCoordinate, to: lastBreadcrumbCoordinate)
//            if remainingDistance < 10 {
//                // Find a point in the route that is 10 meters away
//                guard let nextStep = steps.first(where: { step in
//                    distance(from: step.polyline.coordinate, to: currentCoordinate) > 10
//                }) else { return }
//
//                generateBreadcrumbs(from: lastBreadcrumbCoordinate, to: nextStep.polyline.coordinate)
//            }
//        }
//    }
//
//    func distance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
//        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
//        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
//        return from.distance(from: to)
//    }
//
//
//
//    
//    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
//        if let polyline = overlay as? MKPolyline {
//            let renderer = MKPolylineRenderer(polyline: polyline)
//            renderer.strokeColor = .blue
//            renderer.lineWidth = 3
//            return renderer
//        }
//        return MKOverlayRenderer()
//    }
//    
//    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
//        for anchor in anchors {
//                if let geoAnchor = anchor as? ARGeoAnchor {
//                    guard let currentLocation = locationManager.location else { return }
//
//                    let currentCoordinate = currentLocation.coordinate
//                
//                let distance = self.distance(from: geoAnchor.coordinate, to: currentCoordinate)
//                
//                // print or debug values here
//                print("Distance: \(distance), GeoAnchor Coordinate: \(geoAnchor.coordinate)")
//                
//                if let annotationNode = loadImageAnnotation(named: "restroom") {  // Replace "Image_Name" with the name of your image file
//                    let anchorNode = SCNNode()
//                    anchorNode.addChildNode(annotationNode)
//                    anchorNode.simdTransform = geoAnchor.transform // Set the transform of the anchor node to the anchor's transform
//                    
//                    // Add the node to the scene
//                    sceneLocationView.scene.rootNode.addChildNode(anchorNode)
//                }
//            }
//        }
//    }
//
//    
//    
//    func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
//        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
//        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
//        return from.distance(from: to) // in meters
//    }
//    
//    
//    
//    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor updated: \(geoAnchor)")
//            }
//        }
//    }
//    
//    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor removed: \(geoAnchor)")
//                
//                sceneLocationView.scene.rootNode.enumerateChildNodes { node, _ in
//                    node.removeFromParentNode()
//                }
//            }
//        }
//    }
//}
//

//import UIKit
//import MapKit
//import CoreLocation
//import ARCL
//import ARKit
//
//struct Restroom {
//    let title: String
//    let latitude: Double
//    let longitude: Double
//}
//
//struct GeoJSON: Codable {
//    let features: [Feature]
//}
//
//struct Feature: Codable {
//    let geometry: Geometry
//}
//
//struct Geometry: Codable {
//    let coordinates: [Double]
//}
//
//
//class RestroomAnnotation: NSObject, MKAnnotation {
//    let title: String?
//    let coordinate: CLLocationCoordinate2D
//
//    init(title: String, coordinate: CLLocationCoordinate2D) {
//        self.title = title
//        self.coordinate = coordinate
//    }
//}
//class AROverlayView: UIView {
//    let travelTimeLabel: UILabel
//    let travelDistanceLabel: UILabel
//
//    override init(frame: CGRect) {
//        travelTimeLabel = UILabel()
//        travelDistanceLabel = UILabel()
//
//        super.init(frame: frame)
//
//        // Set some dummy text for initial display
//        travelTimeLabel.text = "Initial travel time"
//        travelDistanceLabel.text = "Initial travel distance"
//
//        // Set text color, font and shadow
//        let customFont = UIFont.boldSystemFont(ofSize: 18) // Change the size to fit your needs
//        let textColor = UIColor.yellow
//        let shadow = NSShadow()
//        shadow.shadowColor = UIColor.black
//        shadow.shadowOffset = CGSize(width: 1, height: 1)
//
//        travelTimeLabel.font = customFont
//        travelTimeLabel.textColor = textColor
//        travelTimeLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelTimeLabel.shadowOffset = shadow.shadowOffset
//
//        travelDistanceLabel.font = customFont
//        travelDistanceLabel.textColor = textColor
//        travelDistanceLabel.shadowColor = shadow.shadowColor as? UIColor
//        travelDistanceLabel.shadowOffset = shadow.shadowOffset
//
//        // Add labels to the AR overlay view
//        self.addSubview(travelTimeLabel)
//        self.addSubview(travelDistanceLabel)
//
//        // Layout configuration code...
//        // Make sure the labels are properly laid out inside the view.
//        travelTimeLabel.translatesAutoresizingMaskIntoConstraints = false
//        travelDistanceLabel.translatesAutoresizingMaskIntoConstraints = false
//        
//        // Set up constraints for labels to display them correctly
//        NSLayoutConstraint.activate([
//            travelTimeLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelTimeLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelTimeLabel.topAnchor.constraint(equalTo: self.topAnchor),
//            travelTimeLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            
//            travelDistanceLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            travelDistanceLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor),
//            travelDistanceLabel.topAnchor.constraint(equalTo: travelTimeLabel.bottomAnchor),
//            travelDistanceLabel.heightAnchor.constraint(equalToConstant: 50), // Set a constant height
//            travelDistanceLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor), // Set the bottom constraint
//        ])
//
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//class LocationNode: SCNNode {
//    var coordinate: CLLocationCoordinate2D!
//    
//    init(location: CLLocation) {
//        super.init()
//        self.coordinate = location.coordinate
//    }
//    
//    required init?(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)
//    }
//}
//
//
//class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
//    
//    var sceneLocationView = SceneLocationView()
//    var mapView = MKMapView()
//    let locationManager = CLLocationManager()
//    var currentCoordinate: CLLocationCoordinate2D?
//    var restrooms: [Restroom] = []
//    var currentRoute: MKRoute?
//    var anchors: [ARGeoAnchor] = []
//    var arOverlayView: AROverlayView?
//    
//    var currentAnnotationNode: LocationAnnotationNode?
//    var annotationNodes: [LocationNode] = []
//  
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Setting up the delegates
//        mapView.delegate = self
//        
//        let configuration = ARWorldTrackingConfiguration()
//        configuration.worldAlignment = .gravityAndHeading
//        
//        // Setting up the AR view
//        sceneLocationView.run()
//        sceneLocationView.session.run(configuration)
//        sceneLocationView.pointOfView?.camera?.zFar = 1000  // Set the far clipping plane to 1000 meters
//        
//        // Setting up the Map view
//        configureLocationServices()
//        loadRestroomLocations()
//        
//        // Adding both the Map and AR view to a stack view and add it to the view hierarchy
//        let stackView = UIStackView(arrangedSubviews: [sceneLocationView, mapView])
//        stackView.axis = .vertical
//        stackView.distribution = .fillEqually
//        stackView.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(stackView)
//        
//        // Constraints for stack view to fill the entire view
//        NSLayoutConstraint.activate([
//            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            stackView.topAnchor.constraint(equalTo: view.topAnchor),
//            stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//        ])
//        
//        arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//        if let arOverlayView = arOverlayView {
//            sceneLocationView.addSubview(arOverlayView)
//        }
//    }
//    
//    
//    func loadImageAnnotation(named: String) -> SCNNode? {
//        let annotationImage = UIImage(named: named)
//        let annotationPlane = SCNPlane(width: 1.0, height: 1.0)
//        annotationPlane.firstMaterial?.diffuse.contents = annotationImage
//        let annotationNode = SCNNode(geometry: annotationPlane)
//        annotationNode.eulerAngles.x = -.pi / 2  // Correct the orientation of the image
//        return annotationNode
//    }
//    
//    
//    
//    func configureLocationServices() {
//        locationManager.delegate = self
//        let authorizationStatus = locationManager.authorizationStatus  // Access the property directly
//        if authorizationStatus == .notDetermined {
//            locationManager.requestWhenInUseAuthorization()
//        } else if authorizationStatus == .authorizedAlways || authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: locationManager)
//        }
//    }
//    
//    func beginLocationUpdates(locationManager: CLLocationManager) {
//        mapView.showsUserLocation = true
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.startUpdatingLocation()
//    }
//    
//    func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
//        let zoomRegion = MKCoordinateRegion.init(center: coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
//        mapView.setRegion(zoomRegion, animated: true)
//    }
//    
//    func addRestroomLocations() {
//        restrooms.forEach { restroom in
//            let annotation = RestroomAnnotation(title: restroom.title, coordinate: CLLocationCoordinate2D(latitude: restroom.latitude, longitude: restroom.longitude))
//            mapView.addAnnotation(annotation)
//        }
//    }
//    
//    
//    func loadRestroomLocations() {
//        guard let url = Bundle.main.url(forResource: "export", withExtension: "geojson") else { return }
//        do {
//            let data = try Data(contentsOf: url)
//            let geoJSON = try JSONDecoder().decode(GeoJSON.self, from: data)
//            geoJSON.features.forEach { feature in
//                let title = "Restroom"
//                let latitude = feature.geometry.coordinates[1]
//                let longitude = feature.geometry.coordinates[0]
//                let restroom = Restroom(title: title, latitude: latitude, longitude: longitude)
//                restrooms.append(restroom)
//            }
//            addRestroomLocations()
//        } catch {
//            print(error)
//        }
//    }
//    
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        guard let latestLocation = locations.first else { return }
//        if currentCoordinate == nil {
//            zoomToLatestLocation(with: latestLocation.coordinate)
//        }
//        
//        currentCoordinate = latestLocation.coordinate
//        
//        // If there's a current destination, regenerate the route
//        if let destination = mapView.selectedAnnotations.first?.coordinate {
//            generateRoute(to: destination)
//        }
//    }
//    
//    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
//        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
//            beginLocationUpdates(locationManager: manager)
//        }
//    }
//    
//    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//        guard let coordinate = view.annotation?.coordinate else { return }
//        
//        // Clear the previous path if any
//        if let currentRoute = self.currentRoute {
//            self.mapView.removeOverlay(currentRoute.polyline)
//            self.currentRoute = nil
//        }
//        
//        if let arOverlayView = arOverlayView {
//            arOverlayView.removeFromSuperview()
//            self.arOverlayView = nil
//        }
//        
//        // Deselect all annotations
//        let allAnnotations = mapView.annotations
//        allAnnotations.forEach { mapView.deselectAnnotation($0, animated: false) }
//        
//        // Clear the previous anchor if any
//        sceneLocationView.removeAllNodes()
//        
//        // Place the new AR node
//        let location = CLLocation(coordinate: coordinate, altitude: 10)
//        let image = UIImage(named: "restroom")!
//        let annotationNode = LocationAnnotationNode(location: location, image: image)
//        sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
//        
//        generateRoute(to: coordinate)
//    }
//
//    
//    
//    func generateRoute(to destination: CLLocationCoordinate2D) {
//        guard let sourceCoordinate = currentCoordinate else { return }
//        
//        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate)
//        let destinationPlacemark = MKPlacemark(coordinate: destination)
//        
//        let sourceItem = MKMapItem(placemark: sourcePlacemark)
//        let destinationItem = MKMapItem(placemark: destinationPlacemark)
//        
//        let directionRequest = MKDirections.Request()
//        directionRequest.source = sourceItem
//        directionRequest.destination = destinationItem
//        directionRequest.transportType = .automobile
//        
//        let directions = MKDirections(request: directionRequest)
//        directions.calculate { [weak self] (response, error) in
//            guard let response = response, let strongSelf = self else { return } // handle error
//            
//            strongSelf.currentRoute = response.routes[0]
//            strongSelf.mapView.addOverlay(strongSelf.currentRoute!.polyline)
//            
//            // Interpolate points along the route's polyline.
//            let points = strongSelf.interpolatePointsAlongPolyline(route: strongSelf.currentRoute!, everyMeters: 10)
//            
//            let numberOfNodes = 10
//            let distanceBetweenNodes = 10.0 / Double(numberOfNodes)
//            
//            for point in points {
//                // Add an AR node at each point.
//                let sphereNode = strongSelf.createSphereLocationNode(radius: 0.1, location: <#CLLocation#>)  // Use new sphere creation function
//                let location = CLLocation(latitude: point.latitude, longitude: point.longitude)
//                let annotationNode = ARCL.LocationNode(location: location)
//                annotationNode.addChildNode(sphereNode)
//                strongSelf.sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
//                
//            }
//            
//            // Store the nodes for further use
//            strongSelf.annotationNodes = points.map { _ in strongSelf.createSphereLocationNode(radius: 0.1, location: <#CLLocation#>) }
//            
//            // Display only the first numberOfNodes nodes
//            for i in 0..<numberOfNodes {
//                strongSelf.annotationNodes[i].isHidden = false
//            }
//        }
//    }
//    
//    
//    func createSphereLocationNode(radius: CGFloat, location: CLLocation) -> LocationNode {
//        let sphere = SCNSphere(radius: radius)
//        sphere.firstMaterial?.diffuse.contents = UIColor.red
//        let node = LocationNode(location: location)
//        node.geometry = sphere
//        node.position.y = -0.75 // setting it 0.75M below user's camera level
//        return node
//    }
//
//
//
//
//    func interpolatePointsAlongPolyline(route: MKRoute, everyMeters: Double) -> [CLLocationCoordinate2D] {
//        let routePoints = route.polyline.points() // Get all points
//        let pointCount = route.polyline.pointCount // Get count of all points
//
//        var interpolatedPoints: [CLLocationCoordinate2D] = []
//
//        for i in 0..<pointCount-1 {
//            let start = routePoints[i].coordinate
//            let end = routePoints[i+1].coordinate
//
//            let startLocation = CLLocation(latitude: start.latitude, longitude: start.longitude)
//            let endLocation = CLLocation(latitude: end.latitude, longitude: end.longitude)
//
//            let distance = startLocation.distance(from: endLocation) // Distance between start and end point in meters
//            let bearing = getBearingBetweenTwoPoints(start: startLocation, end: endLocation) // Bearing from start point to end point
//
//            let numberOfPoints = Int(distance / everyMeters) // Number of points to be added between start and end
//
//            // Add start point to the array
//            interpolatedPoints.append(start)
//
//            if numberOfPoints > 1 {
//                for j in 1...numberOfPoints {
//                    let distanceFromStart = Double(j) * everyMeters
//                    let newPoint = getLocationWithBearing(bearing: bearing, distanceMeters: distanceFromStart, origin: startLocation)
//                    interpolatedPoints.append(newPoint.coordinate)
//                }
//            }
//        }
//        // Add end point of the polyline to the array
//        interpolatedPoints.append(routePoints[pointCount - 1].coordinate)
//
//        return interpolatedPoints
//    }
//
//
//
//    func getBearingBetweenTwoPoints(start: CLLocation, end: CLLocation) -> Double {
//        let lat1 = start.coordinate.latitude.degreesToRadians
//        let lon1 = start.coordinate.longitude.degreesToRadians
//
//        let lat2 = end.coordinate.latitude.degreesToRadians
//        let lon2 = end.coordinate.longitude.degreesToRadians
//
//        let dLon = lon2 - lon1
//
//        let y = sin(dLon) * cos(lat2)
//        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
//        let radiansBearing = atan2(y, x)
//
//        return radiansBearing
//    }
//
//    func getLocationWithBearing(bearing: Double, distanceMeters: Double, origin: CLLocation) -> CLLocation {
//        let distRadians = distanceMeters / (6372797.6) // earth radius in meters
//
//        let lat1 = origin.coordinate.latitude.degreesToRadians
//        let lon1 = origin.coordinate.longitude.degreesToRadians
//
//        let lat2 = asin(sin(lat1) * cos(distRadians) + cos(lat1) * sin(distRadians) * cos(bearing))
//        let lon2 = lon1 + atan2(sin(bearing) * sin(distRadians) * cos(lat1), cos(distRadians) - sin(lat1) * sin(lat2))
//
//        return CLLocation(latitude: lat2.radiansToDegrees, longitude: lon2.radiansToDegrees)
//    }
//
//
//          func startARSession(to destination: CLLocationCoordinate2D, travelTime: TimeInterval, travelDistance: CLLocationDistance) {
//              // Create and set up AR overlay view
//              arOverlayView = AROverlayView(frame: CGRect(x: 20, y: 20, width: self.view.frame.width - 40, height: 120)) // Adjust the width and height as per your needs
//              if let arOverlayView = arOverlayView {
//                  // Display the raw `travelTime` and `travelDistance` values.
//                  arOverlayView.travelTimeLabel.text = String(format: " Time: %.2f minutes", travelTime)
//                  arOverlayView.travelDistanceLabel.text = String(format: "Travel distance: %.2f miles", travelDistance)
//                  sceneLocationView.addSubview(arOverlayView)
//              }
//          }
//
//
//    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
//        if let polyline = overlay as? MKPolyline {
//            let renderer = MKPolylineRenderer(polyline: polyline)
//            renderer.strokeColor = .blue
//            renderer.lineWidth = 3
//            return renderer
//        }
//        return MKOverlayRenderer()
//    }
//
//    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                guard let currentCoordinate = currentCoordinate else { return }
//
//                let distance = calculateDistance(from: geoAnchor.coordinate, to: currentCoordinate)
//
//                // print or debug values here
//                print("Distance: \(distance), GeoAnchor Coordinate: \(geoAnchor.coordinate)")
//
//                if let annotationNode = loadImageAnnotation(named: "restroom") {
//                    let anchorNode = SCNNode()
//
//                    let altitude = geoAnchor.altitude ?? 0.0  // Provide a default value for altitude if it is nil
//                    let location = CLLocation(coordinate: geoAnchor.coordinate, altitude: altitude)
//                    
//                    let locationNode = ARCL.LocationNode(location: location) // Make sure you have the correct naming as per the ARCL version you're using
//
//                    // add the annotationNode as a child of locationNode
//                    locationNode.addChildNode(annotationNode)
//
//                    anchorNode.addChildNode(locationNode)  // add locationNode to anchorNode
//                    anchorNode.simdTransform = geoAnchor.transform // Set the transform of the anchor node to the anchor's transform
//
//                    // Add the node to the scene
//                    sceneLocationView.scene.rootNode.addChildNode(anchorNode)
//                }
//            }
//        }
//    }
//
//
//    func updateNodesBasedOnUserLocation() {
//        guard let currentLocation = currentCoordinate else { return }
//        let userLocation = CLLocation(latitude: currentLocation.latitude, longitude: currentLocation.longitude)
//        
//        let numberOfNodes = 10
//
//        // Calculate the distance between the user and each node
//        for (index, node) in annotationNodes.enumerated() {
//            let nodeLocation = CLLocation(latitude: node.coordinate.latitude, longitude: node.coordinate.longitude)
//            let distance = userLocation.distance(from: nodeLocation)
//
//            if distance < 10 {  // If the user is within 10M of the node
//                node.isHidden = true  // Hide the node
//
//                // Show the next node
//                if index + numberOfNodes < annotationNodes.count {
//                    annotationNodes[index + numberOfNodes].isHidden = false
//                }
//            }
//        }
//    }
//
//
//
//
//    func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
//        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
//        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
//        return from.distance(from: to) // in meters
//    }
//
//
//
//    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor updated: \(geoAnchor)")
//            }
//        }
//    }
//
//    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
//        for anchor in anchors {
//            if let geoAnchor = anchor as? ARGeoAnchor {
//                print("GeoAnchor removed: \(geoAnchor)")
//
//                sceneLocationView.scene.rootNode.enumerateChildNodes { node, _ in
//                    node.removeFromParentNode()
//                }
//            }
//        }
//    }
//    func session(_ session: ARSession, didUpdate frame: ARFrame) {
//        // Update the AR nodes based on the user's location
//        updateNodesBasedOnUserLocation()
//    }
//}
//
//
