//
//  AfterLoginView.swift
//  NYCSBUS 
//
//  Created by Shantanu Anikhindi on 6/27/23.
//  Copyright © 2023 Nasser Jeary. All rights reserved.
//
import SwiftUI

struct AfterLoginView: View {
    @Binding var isLoggedIn: Bool
    var body: some View {
        NavigationView {
            ZStack {
                Color.yellow
                    .ignoresSafeArea()
                Circle()
                    .scale(1.5)
                    .foregroundColor(.white.opacity(0.15))
                Circle()
                    .scale(1.1)
                    .foregroundColor(.white.opacity(0.15))
                VStack {
                    Image("Sandwichito+(1)")
                        .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                        .aspectRatio(contentMode: .fit)
                        .padding(.all)
                        .frame(width:400,height: 250.0)
                    Spacer()
                }
                VStack {
                    Spacer()
                    NavigationLink(destination: EnterBusNumberView()) {
                       Text("Locate a Bus")
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.9))
                        .cornerRadius(10)
                        .foregroundColor(.white)
                }

                    NavigationLink(destination: ViewControllerRepresentable()) {
                        Text("Locate Restrooms")
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.9))
                        .cornerRadius(10)
                        .foregroundColor(.white)
                                    }
                    
                    Spacer()
                    
                    Button("Logout") {
                        isLoggedIn = false
                    }
                    .frame(width: 150, height: 50)
                    .background(Color.black.opacity(0.9))
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .padding(.bottom)
                    
                }
            }.navigationBarHidden(true)
        }
    }
}

struct AfterLoginView_Previews: PreviewProvider {
    static var previews: some View {
        AfterLoginView(isLoggedIn: .constant(true))
    }
}

