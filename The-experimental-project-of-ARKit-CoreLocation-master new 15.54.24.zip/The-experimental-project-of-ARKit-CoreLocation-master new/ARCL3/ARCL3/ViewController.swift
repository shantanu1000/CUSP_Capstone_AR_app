
import UIKit
import ARCL
import CoreLocation
import MapKit

class ViewController: UIViewController, MKMapViewDelegate{

    var sceneLocationView = SceneLocationView()
    var mapView = MKMapView()
    var hasZoomedToUserLocation = false
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()

        sceneLocationView.run()
        view.addSubview(sceneLocationView)

        mapView.delegate = self
        mapView.showsUserLocation = true
        view.addSubview(mapView)

        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        sceneLocationView.frame = view.bounds
        mapView.frame = CGRect(x: 0, y: view.bounds.height - 300, width: view.bounds.width, height: 300)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

         //Define the locations and images for the annotations
        let locations = [
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.696222, longitude: -73.986007), altitude: 20),

            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.689471, longitude: -73.999705), altitude: 20),
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.692886, longitude: -74.001465), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.695754, longitude: -73.999043), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.700784, longitude: -73.995982), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.703270, longitude: -73.991827), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.697836, longitude: -73.979233), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.692246, longitude: -73.977577), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.705642, longitude: -74.003708), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.703152, longitude: -74.006224), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.701334, longitude: -74.013775), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.704308, longitude: -74.015695), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.714716, longitude: -74.010654), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.711563, longitude: -74.010578), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.717375, longitude: -74.011363), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.720034, longitude: -74.012887), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.717471, longitude: -74.015336), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.716617, longitude: -73.993991), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.714706, longitude: -73.988748), altitude: 20),
            
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: 40.726710, longitude: -73.981360), altitude: 20)
        ]


        let images = [
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!,
            UIImage(named: "Geolocation")!
        ]

//         Add the annotation nodes and map annotations for each location
        for i in 0..<locations.count {
            let location = locations[i]
            let image = images[i]

            let userLocation = sceneLocationView.sceneLocationManager.currentLocation ?? CLLocation()
            let distance = userLocation.distance(from: location)
            let scaleFactor = max(1 - distance / 20, 0.25)
            let scaledImage = scaleImage(image, by: scaleFactor)
            let annotationNode = LocationAnnotationNode(location: location, image: scaledImage)
            sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)

            let annotation = MKPointAnnotation()
            annotation.coordinate = location.coordinate
            mapView.addAnnotation(annotation)
//             Add a red sphere as an AR node
//         Add the annotation nodes and map annotations for each location
        }
            }

//    override func viewWillAppear(_ animated: Bool) {
//            super.viewWillAppear(animated)
//
//            let locations = loadLocationsFromCSV()
//
//            // Add the annotation nodes and map annotations for each location
//            for location in locations {
//                let image = UIImage(named: "Geolocation")! // Replace with your desired image
//
//                let userLocation = sceneLocationView.sceneLocationManager.currentLocation ?? CLLocation()
//                let distance = userLocation.distance(from: location)
//                let scaleFactor = max(1 - distance / 20, 0.5)
//                let scaledImage = scaleImage(image, by: scaleFactor)
//
//                let annotationNode = LocationAnnotationNode(location: location, image: scaledImage)
//                sceneLocationView.addLocationNodeWithConfirmedLocation(locationNode: annotationNode)
//
//                let annotation = MKPointAnnotation()
//                annotation.coordinate = location.coordinate
//                mapView.addAnnotation(annotation)
//                        }
//                    }
//
//        // Add the loadLocationsFromCSV method here
//        func loadLocationsFromCSV() -> [CLLocation] {
//            guard let csvURL = Bundle.main.url(forResource: "Location_Toilets", withExtension: "csv") else {
//                print("Failed to find locations.csv file")
//                return []
//            }
//
//            do {
//                let csvData = try String(contentsOf: csvURL, encoding: .utf8)
//                let lines = csvData.components(separatedBy: "\n")
//
//                var locations: [CLLocation] = []
//
//                for line in lines {
//                    let components = line.components(separatedBy: ",")
//                    if components.count == 2,
//                       let latitude = Double(components[0]),
//                       let longitude = Double(components[1]) {
//                        let location = CLLocation(latitude: latitude, longitude: longitude)
//                        locations.append(location)
//                    }
//                }
//
//                return locations
//            } catch {
//                print("Failed to load locations from CSV: \(error)")
//                return []
//            }
//        }
    
    
    

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            // User Location Annotation
            let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: nil)
            annotationView.image = UIImage(named: "UserLocation")?.withRenderingMode(.alwaysTemplate) // Set the user location image
            annotationView.canShowCallout = false
            let scale = min(50 / annotationView.image!.size.width, 50 / annotationView.image!.size.height)
            let size = CGSize(width: annotationView.image!.size.width * scale, height: annotationView.image!.size.height * scale)
            annotationView.frame = CGRect(origin: CGPoint.zero, size: size)
            return annotationView
        } else {
            // Target Location Annotation
            let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: nil)
            annotationView.image = UIImage(named: "restroom")?.withRenderingMode(.alwaysTemplate) // Set the target image
            annotationView.canShowCallout = false
            let scale = min(30 / annotationView.image!.size.width, 30 / annotationView.image!.size.height)
            let size = CGSize(width: annotationView.image!.size.width * scale, height: annotationView.image!.size.height * scale)
            annotationView.frame = CGRect(origin: CGPoint.zero, size: size)
            return annotationView
        }
    }


        func scaleImage(_ image: UIImage, by scaleFactor: CGFloat) -> UIImage {
            let size = CGSize(width: image.size.width * scaleFactor, height: image.size.height * scaleFactor)
            UIGraphicsBeginImageContext(size)
            image.draw(in: CGRect(origin: .zero, size: size))
            let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return scaledImage ?? image
        }
    
    }




extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }

        // only zoom to user's location on first update
        if !hasZoomedToUserLocation {
            let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 100, longitudinalMeters: 100)
            mapView.setRegion(region, animated: true)
            hasZoomedToUserLocation = true
        }
    }
}


  
